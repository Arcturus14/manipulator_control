"""CUDA-only N0 covariance/temperature tuning; no disturbance and no DOB.

Does not modify frozen study/GUI defaults or run an N0/N1 comparison.
"""
import argparse
import gc
import hashlib
import json
from pathlib import Path
import shutil
import numpy as np
import torch
from config import DT,TAU_MAX
from experiment_runner import run_mppi
from benchmarks.benchmark_dob_aware_nominal_shift import cuda_preflight
from kroc.input_headroom_study import InputHeadroomTracker
from controllers.mppi_dob_controller import UR5Tracker
from kroc.run_pre_input_baseline import load_preset
from kroc.run_input_headroom_study import run_options
from kroc.position_input_headroom_study import metrics,usable
from kroc.search_lowfreq_estimator_margin import geometry
from kroc.audit_circle_validation import dense_mesh_check

ROOT=Path('kroc/results/normalized_covariance_20261116')
SIGMAS=[.01,.02,.03,.05,.10]
TEMPERATURES=[1.,4.,16.,64.]
PILOT=6107
VALIDATION=[6207,6217,6227,6237,6247]


def write(path,value):
    path.write_text(json.dumps(value,indent=2,allow_nan=False))


def covariance(sigma):
    return ((float(sigma)*np.asarray(TAU_MAX,dtype=float))**2).tolist()


class NoDOBN0Tracker(InputHeadroomTracker):
    """Keep all N0 sampling/cost semantics; permit actual DOB OFF operation."""
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        if self.study_case!='N0':raise ValueError('Only N0 is authorized for this study')
        self.cost_diagnostics=[]
        original=self.ctrl._compute_weighting
        def weighting(total):
            weights=original(total)
            sorted_cost=total.sort().values
            gap=sorted_cost[1]-sorted_cost[0]
            self.cost_diagnostics.append(torch.stack((sorted_cost[0],gap,gap/self.ctrl.lambda_,
                total.std(unbiased=False),weights.max(),-(weights*weights.clamp_min(1e-30).log()).sum(),total.mean())).detach())
            return weights
        self.ctrl._compute_weighting=weighting

    def run(self,*args,**kwargs):
        if kwargs.get('use_dob',False) or kwargs.get('has_disturbance',False):
            raise ValueError('This tuning stage requires both disturbance and DOB OFF')
        self.request_sample_fraction.clear();self.headroom_sample_cost.clear();self.cost_diagnostics.clear()
        self.sensor_model.reset();self.measured_state_history.clear()
        self.margin_history.clear();self.margins.reset()
        return UR5Tracker.run(self,*args,**kwargs)

    def _warm_up_controller(self,*args,**kwargs):
        super()._warm_up_controller(*args,**kwargs)
        self.cost_diagnostics.clear()

    def export_sensor_data(self):
        data=super().export_sensor_data()
        data['covariance_weight_diagnostics']=torch.stack(self.cost_diagnostics).cpu().numpy()
        return data


def specifications():
    base=load_preset()
    return [dict(name='baseline',sigma_norm=None,temperature=base['temperature'],variance=base['noise_variance'])]+[
        dict(name=f's{s:g}_l{t:g}',sigma_norm=s,temperature=t,variance=covariance(s)) for s in SIGMAS for t in TEMPERATURES]


def freeze(cuda):
    ROOT.mkdir(parents=True,exist_ok=True)
    path=ROOT/'plan.json'
    if path.exists():
        plan=json.loads(path.read_text())
        for file,digest in plan['source_sha256'].items():
            if hashlib.sha256(Path(file).read_bytes()).hexdigest()!=digest:raise RuntimeError('Frozen source changed: '+file)
        return plan
    old=json.loads(Path('kroc/results/input_headroom_final_checks_20261115/manifest.json').read_text())
    for file,digest in old['source_sha256'].items():
        if hashlib.sha256(Path(file).read_bytes()).hexdigest()!=digest:raise RuntimeError('Original study source changed: '+file)
    files=list(old['source_sha256'])+[str(Path(__file__).relative_to(Path.cwd()))]
    for file in files:
        relative=Path(file).resolve().relative_to(Path.cwd())
        dst=ROOT/'source'/relative;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(file,dst)
    plan=dict(cuda=cuda,base=load_preset(),specifications=specifications(),pilot_seed=PILOT,validation_seeds=VALIDATION,
        scenario='Original geometry(.89): 4cm XY circle,6s; disturbance OFF; DOB estimator and compensation OFF; sensor noise retained',
        changes_only='diagonal covariance and temperature; N0 unbounded nominal samples/output; final physical clamp retained',
        diagnostic_columns=['min_cost','best_second_gap','gap_over_lambda','cost_std','max_weight','entropy','mean_cost'],
        selection='Safe pilot runs ranked by RMSE,max_error,torque_rate,-ESS. Freeze top3 and primary=rank1 before validation. Baseline+top3 on five independent seeds. No reselection using validation.',
        confirmation_gate='Primary: all five safe, mean RMSE <= .95*baseline, mean maxerror <=1.05*baseline. Report every paired outcome, torque rate, ESS, clipping. If gate fails, do not promote or pick another validation winner.',
        stop_boundary='Stop BEFORE any N0/N1 comparison or disturbance/DOB ON run; no GUI/default edits',
        source_sha256={file:hashlib.sha256(Path(file).read_bytes()).hexdigest() for file in files})
    write(path,plan);return plan


def audit(z,spec):
    assert str(z['compute_device'])=='cuda'
    assert str(z['input_study_case'])=='N0' and not bool(z['input_study_fixed_clip'])
    assert float(z['input_study_headroom_weight'])==0.
    for key in ['q','qd','err_mm','u_mppi','u_applied','covariance_weight_diagnostics']:
        if not np.isfinite(z[key]).all():raise RuntimeError('Nonfinite '+key)
    for key in ['d_true','d_hat','d_hat_used']:
        if key in z:np.testing.assert_array_equal(z[key],np.zeros_like(z[key]))
    np.testing.assert_array_equal(z['u_effective_pred'],z['u_mppi'])
    np.testing.assert_allclose(z['u_applied'],np.clip(z['u_mppi'],-np.asarray(TAU_MAX),TAU_MAX),atol=3e-6,rtol=1e-6)
    expected=np.broadcast_to(np.asarray(spec['variance'],np.float32),(300,6))
    np.testing.assert_array_equal(z['mppi_active_noise_variance'],expected)
    assert float(z['mppi_temperature'])==spec['temperature']
    assert float(z['mppi_temporal_noise_rho'])==1.
    assert z['covariance_weight_diagnostics'].shape==(300,7)


def run_one(phase,spec,seed):
    folder=ROOT/phase;folder.mkdir(exist_ok=True)
    path=folder/f'{spec["name"]}_seed{seed}.npz';meta=path.with_suffix('.json')
    if meta.exists():return json.loads(meta.read_text())
    print('RUN',phase,spec['name'],seed,flush=True)
    if not path.exists():
        reference,q0,_=geometry(.89)
        opts=run_options(load_preset(),seed,'N0',0.)
        opts.update(use_dob=False,tracker_class=NoDOBN0Tracker,temperature=spec['temperature'],noise_variance=spec['variance'])
        z=run_mppi(reference,initial_q=q0,has_disturbance=False,**opts)
        z.update(circle_reference=reference,study_joint=np.asarray(2),covariance_sigma_norm=np.asarray(spec['sigma_norm'] if spec['sigma_norm'] is not None else -1.))
        audit(z,spec)
        np.savez_compressed(path,**{k:v for k,v in z.items() if not k.startswith('_')})
        del z;gc.collect();torch.cuda.empty_cache()
    mesh=dense_mesh_check((str(path),4))
    with np.load(path) as z:
        audit(z,spec);m=metrics(z);ess=z['mppi_weight_ess'];diag=z['covariance_weight_diagnostics']
        m.update(ess_lt2_fraction=float((ess<2).mean()),ess_ge5_fraction=float((ess>=5).mean()),
            ess_p90=float(np.percentile(ess,90)),gap_over_lambda_median=float(np.median(diag[:,2])),
            gap_median=float(np.median(diag[:,1])),cost_std_median=float(np.median(diag[:,3])),
            max_weight_mean=float(diag[:,4].mean()),rollout_min_cost_mean=float(diag[:,0].mean()),
            rollout_mean_cost_mean=float(diag[:,6].mean()),sample_request_excess_fraction=float(z['input_study_sample_request_excess_fraction'].mean()))
    row=dict(phase=phase,spec=spec,seed=seed,path=str(path),mesh_5ms=mesh,full_metrics=m)
    row['safe']=usable(row)
    write(meta,row)
    print('RESULT',phase,spec['name'],seed,'RMSE',m['rmse_mm'],'ESS',m['ess_mean'],'rate',m['torque_rate_rms_nm_s'],'safe',row['safe'],flush=True)
    return row


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--phase',choices=['all','pilot','validation'],default='all');args=parser.parse_args()
    cuda=cuda_preflight();print('PREFLIGHT',cuda,flush=True);plan=freeze(cuda)
    selected=ROOT/'selection.json'
    if args.phase in ['all','pilot']:
        rows=[]
        for spec in plan['specifications']:
            rows.append(run_one('pilot',spec,PILOT));write(ROOT/'pilot_progress.json',rows)
        ranked=sorted([r for r in rows if r['safe'] and r['spec']['name']!='baseline'],key=lambda r:(r['full_metrics']['rmse_mm'],r['full_metrics']['max_error_mm'],r['full_metrics']['torque_rate_rms_nm_s'],-r['full_metrics']['ess_mean']))
        if len(ranked)<3:raise RuntimeError('Fewer than three safe candidates; report before extending search')
        selection=dict(primary=ranked[0]['spec'],top3=[r['spec'] for r in ranked[:3]],pilot=rows,locked_before_validation=True)
        if selected.exists():assert json.loads(selected.read_text())==selection
        else:write(selected,selection)
        print('PILOT_SELECTION',selection['top3'],flush=True)
    if args.phase in ['all','validation']:
        choice=json.loads(selected.read_text());specs=[plan['specifications'][0]]+choice['top3'];rows=[]
        for seed in VALIDATION:
            for spec in specs:
                rows.append(run_one('validation',spec,seed));write(ROOT/'validation_progress.json',rows)
        write(ROOT/'completed.json',dict(pilot_runs=21,validation_runs=len(rows),stopped_before_N0_N1=True))
    print('DONE',args.phase,flush=True)


if __name__=='__main__':main()
