import unittest
from unittest.mock import Mock,patch
import numpy as np
from kroc.tune_normalized_covariance import covariance,specifications,NoDOBN0Tracker

class CovarianceTests(unittest.TestCase):
    def test_normalized_authority_fraction(self):
        np.testing.assert_allclose(covariance(.1),[225,225,225,7.84,7.84,7.84])
        self.assertEqual(len(specifications()),21)
    def test_off_dispatch_preserves_sensor_and_margin_reset(self):
        tracker=object.__new__(NoDOBN0Tracker)
        for name in ['sensor_model','margins','measured_state_history','margin_history','request_sample_fraction','headroom_sample_cost','cost_diagnostics']:
            setattr(tracker,name,Mock())
        with patch('kroc.tune_normalized_covariance.UR5Tracker.run',return_value='episode') as run:
            self.assertEqual(tracker.run(use_dob=False,has_disturbance=False),'episode')
            run.assert_called_once_with(tracker,use_dob=False,has_disturbance=False)
        tracker.sensor_model.reset.assert_called_once()
        tracker.margins.reset.assert_called_once()
        tracker.margin_history.clear.assert_called_once()

    def test_no_dob_guard(self):
        tracker=object.__new__(NoDOBN0Tracker)
        for flags in [dict(use_dob=True),dict(has_disturbance=True)]:
            with self.assertRaisesRegex(ValueError,'OFF'):tracker.run(**flags)

if __name__=='__main__':unittest.main()
