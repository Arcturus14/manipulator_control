"""Intermediate report: N0 no-disturbance/no-DOB tuning only."""
import csv
import hashlib
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from kroc.tune_normalized_covariance import ROOT,SIGMAS,TEMPERATURES,VALIDATION,audit

OUT=Path('kroc/reports/normalized_covariance_20261116')
BLUE='#2364AA';ORANGE='#D87924'
plt.rcParams.update({'font.size':10,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})


def write(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False))
def stats(rows):
    keys=['rmse_mm','max_error_mm','torque_rate_rms_nm_s','ess_mean','ess_median','ess_lt2_fraction','gap_over_lambda_median','clip_steps','jclip_nm_s','rollout_min_cost_mean','rollout_mean_cost_mean','sample_request_excess_fraction']
    return dict(n=len(rows),safe=sum(r['safe'] for r in rows),
        mean={k:float(np.mean([r['full_metrics'][k] for r in rows])) for k in keys},
        sd={k:float(np.std([r['full_metrics'][k] for r in rows],ddof=1)) for k in keys})
def table(headers,rows):
    return ['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(map(str,row))+' |' for row in rows]+['']
def save(fig,name):
    fig.savefig(OUT/(name+'.png'),dpi=220,bbox_inches='tight');fig.savefig(OUT/(name+'.svg'),bbox_inches='tight');plt.close(fig)


def main():
    assert (ROOT/'completed.json').exists(),'Do not publish partial confirmation'
    OUT.mkdir(parents=True,exist_ok=True)
    plan=json.loads((ROOT/'plan.json').read_text());choice=json.loads((ROOT/'selection.json').read_text())
    pilot=choice['pilot'];validation=json.loads((ROOT/'validation_progress.json').read_text());assert len(validation)==20
    for file,digest in plan['source_sha256'].items():assert hashlib.sha256(Path(file).read_bytes()).hexdigest()==digest,file
    # Recompute the key physical metrics, compare paired input conditions and all raw audits.
    first={}
    for row in pilot+validation:
        with np.load(row['path']) as z:
            audit(z,row['spec'])
            assert abs(float(np.sqrt(np.mean(z['err_mm']**2)))-row['full_metrics']['rmse_mm'])<1e-9
            common={key:z[key].copy() for key in ['circle_reference','initial_q','sensor_noise_seed','d_true']}
            if row['seed'] in first:
                for key,value in common.items():np.testing.assert_array_equal(first[row['seed']][key],value)
            else:first[row['seed']]=common
    names=['baseline']+[s['name'] for s in choice['top3']]
    groups={name:stats([r for r in validation if r['spec']['name']==name]) for name in names}
    b=groups['baseline'];primary=choice['primary'];c=groups[primary['name']]
    gate=(c['safe']==5 and c['mean']['rmse_mm']<=.95*b['mean']['rmse_mm'] and c['mean']['max_error_mm']<=1.05*b['mean']['max_error_mm'])
    changes={k:100*(c['mean'][k]/b['mean'][k]-1) for k in ['rmse_mm','max_error_mm','torque_rate_rms_nm_s','ess_mean']}
    pairs=[]
    for seed in VALIDATION:
        br=next(r for r in validation if r['seed']==seed and r['spec']['name']=='baseline')
        cr=next(r for r in validation if r['seed']==seed and r['spec']['name']==primary['name'])
        pairs.append(dict(seed=seed,baseline=br,candidate=cr,rmse_improved=cr['full_metrics']['rmse_mm']<br['full_metrics']['rmse_mm']))
    analysis=dict(primary=primary,confirmation_passed=gate,groups=groups,changes_pct=changes,
        pairs=pairs,all_runs_safe=all(r['safe'] for r in pilot+validation),pilot_runs=21,validation_runs=20,
        default_changed=False,N0_N1_comparison_performed=False,selected_from_pilot_only=True)
    write(OUT/'analysis.json',analysis)
    candidate=dict(status='confirmed_candidate_not_applied' if gate else 'not_confirmed_do_not_apply',
        controller='N0',confirmation_scope='No disturbance, DOB OFF; same 4cm/6s circle, sensor noise ON',
        temperature=primary['temperature'],noise_variance=primary['variance'],sigma_norm=primary['sigma_norm'],
        input_tightening=False,temporal_noise_rho=1.,headroom_weight=0.,requires_followup_N0_N1=True)
    write(OUT/'candidate_config.json',candidate)
    with (OUT/'all_runs.csv').open('w',newline='') as f:
        fields=['phase','seed','name','sigma_norm','temperature','safe']+list(groups['baseline']['mean'])
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
        for row in pilot+validation:
            writer.writerow(dict(phase=row['phase'],seed=row['seed'],name=row['spec']['name'],sigma_norm=row['spec']['sigma_norm'],temperature=row['spec']['temperature'],safe=row['safe'],**{k:row['full_metrics'][k] for k in groups['baseline']['mean']}))
    fig,axes=plt.subplots(1,3,figsize=(13,4),layout='constrained')
    for ax,key,title in zip(axes,['rmse_mm','ess_mean','torque_rate_rms_nm_s'],['Pilot EE RMSE [mm]','Pilot mean ESS','Pilot torque-rate RMS [Nm/s]']):
        values=np.array([[next(r for r in pilot if r['spec']['sigma_norm']==s and r['spec']['temperature']==t)['full_metrics'][key] for t in TEMPERATURES] for s in SIGMAS])
        image=ax.imshow(values,aspect='auto',cmap='viridis');fig.colorbar(image,ax=ax,fraction=.045)
        for i in range(5):
            for j in range(4):
                color='white' if values[i,j]<(values.min()+values.max())/2 else 'black'
                valid=next(r for r in pilot if r['spec']['sigma_norm']==SIGMAS[i] and r['spec']['temperature']==TEMPERATURES[j])['safe']
                ax.text(j,i,f'{values[i,j]:.2f}'+(' !' if not valid else ''),ha='center',va='center',fontsize=8,color=color)
        ax.set(xticks=range(4),xticklabels=[f'{t:g}' for t in TEMPERATURES],yticks=range(5),yticklabels=[f'{s:g}' for s in SIGMAS],xlabel='Temperature lambda',ylabel='Normalized noise std',title=title)
    save(fig,'fig01_pilot_grid')
    fig,axes=plt.subplots(1,3,figsize=(12,4),layout='constrained')
    for ax,key,label in zip(axes,['rmse_mm','ess_mean','torque_rate_rms_nm_s'],['EE RMSE [mm]','Mean ESS','Torque-rate RMS [Nm/s]']):
        values=np.array([[p[case]['full_metrics'][key] for case in ['baseline','candidate']] for p in pairs])
        for row in values:ax.plot([0,1],row,color='gray',alpha=.5)
        for i,color in [(0,BLUE),(1,ORANGE)]:ax.scatter(np.full(5,i),values[:,i],color=color)
        ax.errorbar([0,1],values.mean(0),yerr=values.std(0,ddof=1),fmt='D',color='black',capsize=4)
        ax.set(xticks=[0,1],xticklabels=['Baseline','Primary'],ylabel=label,title='5 independent paired seeds');ax.grid(axis='y',alpha=.2)
    save(fig,'fig02_validation_pairs')
    fig,axes=plt.subplots(1,2,figsize=(11,4),layout='constrained')
    for case,color in [('baseline',BLUE),('candidate',ORANGE)]:
        arrays=[];weights=[]
        for p in pairs:
            with np.load(p[case]['path']) as z:arrays.append(z['err_mm']);weights.append(z['mppi_weight_ess'])
        for ax,a in zip(axes,[arrays,weights]):
            a=np.array(a);t=(np.arange(300)+1)*.02;ax.plot(t,a.mean(0),color=color,label=case)
            ax.fill_between(t,a.min(0),a.max(0),color=color,alpha=.13)
    for ax,label in zip(axes,['EE error [mm]','ESS']):ax.set(xlabel='Time [s]',ylabel=label);ax.grid(alpha=.2);ax.legend()
    save(fig,'fig03_time_response')
    rows=[]
    for name in names:
        g=groups[name];m=g['mean'];sd=g['sd']
        rows.append([name,f"{g['safe']}/5",f"{m['rmse_mm']:.3f} ± {sd['rmse_mm']:.3f}",f"{m['max_error_mm']:.3f}",f"{m['ess_mean']:.2f}",f"{m['torque_rate_rms_nm_s']:.2f}",f"{m['clip_steps']:.1f}"])
    md=['# N0 covariance–temperature 튜닝 중간 보고','', '2026-11-16 | 외란 OFF · DOB 추정/보상 OFF · 센서 노이즈 ON','',
        f"예비21회와 독립 검증20회, 총41회 CUDA 실행을 완료했다. N0/N1 비교는 수행하지 않았고 GUI·확정 Base도 변경하지 않았다.",'',
        '## 결과와 선정','',f"예비 seed {plan['pilot_seed']}의 RMSE 우선 순위로 고정한 1순위는 **σ_norm={primary['sigma_norm']:g}, λ={primary['temperature']:g}**다. 독립 검증 기준 통과={gate}.",'',
        f"기존 대비 평균 RMSE {changes['rmse_mm']:+.1f}%, 최대오차 {changes['max_error_mm']:+.1f}%, torque-rate {changes['torque_rate_rms_nm_s']:+.1f}%. 평균 ESS {b['mean']['ess_mean']:.2f}→{c['mean']['ess_mean']:.2f}. RMSE 개선 {sum(p['rmse_improved'] for p in pairs)}/5쌍.",'',
        'RMSE 단위는 mm, torque-rate는 Nm/s. ±는 seed별 표본 SD다. 나머지 두 후보도 공개하되 독립 검증 결과를 보고 1순위를 재선정하지 않는다.','']
    pilot_base=next(r['full_metrics'] for r in pilot if r['spec']['name']=='baseline')
    pilot_primary=next(r['full_metrics'] for r in pilot if r['spec']['name']==primary['name'])
    md += [f"예비 seed에서는 기존 RMSE {pilot_base['rmse_mm']:.3f}→{pilot_primary['rmse_mm']:.3f} mm였다. 이 한 seed에서의 선정 이점과 독립 검증 결과를 구분해야 한다.",'']
    if not gate:
        md += [f"**판정: 평균 RMSE 감소율은 {-changes['rmse_mm']:.3f}%로 사전에 정한5.000% 기준에 근소하게 미달했다. 이5%는 공학적 채택 기준이며 통계적 유의수준이 아니다. 현재 해석은 평균 추종오차의 소폭 감소와 토크 변화율의 큰 감소다. 기본값은 유지하고 큰 추종 개선의 확정 판단은 보류한다.**",'', '다른 후보를 검증 결과만 보고 대신 채택하지 않는다.','']
    else:
        md += ['**판정: 사전 독립 검증 기준을 충족한 후보이며, 사용자 확인 전까지 기존 기본값에는 적용하지 않는다. 연구 외란 조건에서의 이점은 아직 검증하지 않았다.**','']
    md+=table(['설정','접촉·상태 검사','RMSE 평균±SD','최대오차 평균','ESS 평균','Torque-rate 평균','Clip step 평균'],rows)
    md+=['## 정확한 설정과 변경 범위','',
        f"- Covariance 대각 원소 [Nm²]: {primary['variance']}",
        f"- 표준편차 [Nm]: {np.sqrt(primary['variance']).round(5).tolist()}",
        '- 고정: K136, H10, dt .02s, λ 외 모든 비용 계수, mean update alpha1, horizon 공유 Gaussian 노이즈, FF+residual warm start.',
        '- 고정 상태 마진2.5%, 충돌 비용/감사, q/dq 측정 노이즈 .001rad/.01rad/s를 유지했다.',
        '- N0 nominal 샘플·출력은 hard clamp하지 않고 실제 actuator만 물리 한도로 clamp했다.',
        '- 기존 DOB 필수 래퍼의 진입 가드만 별도 어댑터에서 우회했다. 센서·고정 마진 초기화는 유지하고 실제 DOB update/보상은 OFF다. 원래 연구 코드는 수정하지 않았다.','',
        '## 실험과 데이터 분리','',
        f"예비 seed={plan['pilot_seed']}; σ_norm={SIGMAS}, λ={TEMPERATURES}의20개 조합+기존 covariance/λ1을 비교했다. 안전 후보를 RMSE→최대오차→torque-rate→ESS 순으로 정렬하고 상위3개와 1순위를 검증 전 고정했다.",'',
        f"독립 seed={VALIDATION}. 기존 설정+고정3개 후보를 같은 참조·초기값·센서 노이즈 seed로 비교했다. 1순위 확인 기준은 5회 모두 접촉/상태 위반 없음, 평균 RMSE≥5% 감소, 평균 최대오차 증가≤5%였다. 실패 시 다른 검증 승자를 대체 채택하지 않는다.",'',
        '## Figure 1: 예비 후보 전체 비교','', '![Pilot grid](fig01_pilot_grid.png)','',
        '동일 seed에서 covariance와 temperature를 함께 바꾼20개 조합이다. 셀은 각 실행의 지표이며 여러 seed의 평균이 아니다. ! 표시는 접촉/상태 검사 실패이며 성능 개선으로 채택하지 않는다. ESS만 높이는 설정 대신 추종 성능을 우선해 선택했다.','',
        '## Figure 2: 독립 seed의 paired 비교','', '![Paired validation](fig02_validation_pairs.png)','',
        '회색 선은 같은 seed의 기존 설정과 예비1순위를 연결한다. 검은 다이아몬드는 평균±표본 SD이며 신뢰구간이 아니다.','',
        '## Figure 3: 오차와 ESS 시간 응답','', '![Time response](fig03_time_response.png)','',
        '선은5개 seed 평균, 음영은 min–max다. 시간 표본을 독립 실행으로 늘려 통계를 계산하지 않았다.','',
        '## 가중치 진단과 해석','']
    md+=table(['설정','(차저−최저 비용)/λ 중앙값 평균','ESS<2 비율 평균','최소 rollout 비용 평균','평균 rollout 비용 평균'],[[name,f"{groups[name]['mean']['gap_over_lambda_median']:.3f}",f"{groups[name]['mean']['ess_lt2_fraction']:.3f}",f"{groups[name]['mean']['rollout_min_cost_mean']:.3f}",f"{groups[name]['mean']['rollout_mean_cost_mean']:.3f}"] for name in names])
    md+=['같은 normalized covariance에서 λ만 바꾼 예비 비교를 아래에 분리했다. 이는 단일 예비 seed의 결과이며 독립 seed 검증은 위의 고정 상위3개에 대해서만 수행했다.','']
    effects=[]
    for sigma in SIGMAS:
        left=next(r['full_metrics'] for r in pilot if r['spec']['sigma_norm']==sigma and r['spec']['temperature']==1.)
        right=next(r['full_metrics'] for r in pilot if r['spec']['sigma_norm']==sigma and r['spec']['temperature']==64.)
        effects.append([f'{sigma:g}',f"{left['ess_mean']:.2f} / {right['ess_mean']:.2f}",f"{left['rmse_mm']:.3f} / {right['rmse_mm']:.3f}",f"{left['torque_rate_rms_nm_s']:.2f} / {right['torque_rate_rms_nm_s']:.2f}"])
    md+=table(['σ_norm','ESS λ1/λ64','RMSE λ1/λ64','Torque-rate λ1/λ64'],effects)
    md+=['Covariance는 후보의 비용 분포를 바꾸고 λ는 그 분포의 가중치 집중도를 바꾼다. 두 값을 함께 바꾼 최종 후보의 효과 전체를 covariance 하나의 인과 효과로 해석하지 않는다. Rollout 비용은 각기 다른 후보 분포와 폐루프 상태에서 평가된 값으로, 공통 실제 성능 목적함수의 직접 비교값이 아니다. 진단 계측은 GPU solve 중 비용 정렬·통계 연산을 추가하므로 timing은 원래 제어기와 비교하거나 실시간 주장에 사용하지 않는다.','',
        '## 검증 범위와 다음 단계','',
        '현재 확인 범위는 같은 자세·6초 원궤적의 외란/DOB OFF 조건이다. 큰 외란에서의 탐색 능력과 N1의 추가 이점, 다른 궤적·자세 및 하드웨어는 확인하지 않았다. 토크 한도 비율을 맞추는 것은 상태에 미치는 동역학적 영향까지 같게 만드는 정규화가 아니다. 각 관절의 관성·기구학적 민감도가 달라 추종 최적 covariance라는 보장은 없다. 선정값을 외란 조건에 그대로 적용할 때 동작이 유지된다는 보장도 없다. 특히 λ 변화는 N1 접근 비용이 후보 선택에 미치는 영향도 바꾸므로 별도 확인이 필요하다.','',
        '사용자의 중간 정지 요청에 따라 여기서 종료한다. 다음 승인 단계에서 후보의 (Σ,λ)를 N0/N1 공통으로 고정하고 연구 외란 조건을 비교할 수 있다. 기존 확정 결과를 대체하거나 N1 가중치를 재튜닝하지 않았다.','',
        '## 실행별 자료','']
    md+=table(['Seed','기존 RMSE','후보 RMSE','기존 ESS','후보 ESS','기존 rate','후보 rate'],[[str(p['seed'])]+[f"{p[case]['full_metrics'][key]:.4f}" for key in ['rmse_mm','ess_mean','torque_rate_rms_nm_s'] for case in ['baseline','candidate']] for p in pairs])
    md+=['## 재현과 무결성','',f'원자료: `{ROOT}`. `plan.json`에 사전 계획·동결 소스·CUDA 정보, `selection.json`에 검증 전 후보 선정, NPZ에 비용 분포 진단과 상태·입력·센서·추정값을 보존했다.',
        '', '편집용 본문 report.md, 집계 analysis.json, 전체41회 all_runs.csv, 미적용 후보 candidate_config.json, PNG/SVG 그림3개를 함께 제공한다. 초기 실행 경로 준비 오류는 시뮬레이션 결과가 생성되기 전에 발생했고 initialization 기록에 분리했다.','']
    (OUT/'report.md').write_text('\n'.join(md))
    write(ROOT/'integrity.json',dict(completed_cuda_runs=41,source_hashes_verified=True,raw_audits_passed=True,paired_reference_and_noise_verified=True,
        N0_N1_not_run=True,raw_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*/*.npz')}))
    print(json.dumps(analysis,indent=2)[:4000])


if __name__=='__main__':main()
