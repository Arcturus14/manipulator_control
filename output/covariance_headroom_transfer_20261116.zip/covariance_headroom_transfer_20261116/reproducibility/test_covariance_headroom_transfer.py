import unittest
import numpy as np
from kroc.compare_covariance_headroom import joint_metrics,specifications,SEEDS

class TransferTests(unittest.TestCase):
    def test_factorial_and_equal_n0_n1_parameters(self):
        s=specifications()
        self.assertEqual(sum(len(x['cases']) for x in s.values())*len(SEEDS),30)
        self.assertEqual(s['new_l1']['variance'],s['new_l64']['variance'])
        self.assertEqual(s['old_l1']['variance'],s['old_l64']['variance'])
        self.assertEqual(s['old_l1']['cases'],['N0','N1'])
    def test_actuator_and_nominal_rates_are_distinct(self):
        t=np.arange(4)[:,None]*.02
        z=dict(u_mppi=t*np.arange(1,7)[None,:],u_applied=2*t*np.arange(1,7)[None,:],
            d_hat_used=np.zeros((4,6)),q=np.zeros((5,6)),q_reference=np.zeros((5,6)),qd=np.zeros((5,6)))
        m=joint_metrics(z)
        np.testing.assert_allclose(m['nominal_rate_per_joint_nm_s'],np.arange(1,7),rtol=1e-7)
        np.testing.assert_allclose(m['applied_rate_per_joint_nm_s'],2*np.arange(1,7),rtol=1e-7)

if __name__=='__main__':unittest.main()
