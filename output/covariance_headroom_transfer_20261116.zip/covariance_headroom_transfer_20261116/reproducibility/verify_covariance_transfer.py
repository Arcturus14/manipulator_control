"""Reproduce one archived seed and one newly observed large-error run."""
import hashlib
import json
from pathlib import Path
import numpy as np
import kroc.compare_covariance_headroom as experiment
from benchmarks.benchmark_dob_aware_nominal_shift import cuda_preflight


def main():
    root=experiment.ROOT
    assert (root/'completed.json').exists()
    cuda=cuda_preflight();print('PREFLIGHT',cuda,flush=True)
    plan=json.loads((root/'plan.json').read_text())
    for file,digest in plan['source_sha256'].items():assert hashlib.sha256(Path(file).read_bytes()).hexdigest()==digest,file
    experiment.ROOT=root/'reproduction';experiment.ROOT.mkdir(exist_ok=True)
    results=[]
    for seed,original in [(5307,Path('kroc/results/input_headroom_final_checks_20261115/primary_132p5/N1_seed5307.npz')),
                          (6307,root/'old_l1/N1_seed6307.npz')]:
        row=experiment.run_one('old_l1',plan['specifications']['old_l1'],'N1',seed)
        with np.load(original) as a,np.load(row['path']) as b:
            keys=['q','qd','ee','err_mm','u_mppi','u_applied','d_hat_used','u_effective_pred','d_true','circle_reference']
            equal={k:bool(np.array_equal(a[k],b[k])) for k in keys}
            maximum={k:float(np.max(np.abs(a[k]-b[k]))) for k in keys}
        result=dict(seed=seed,original=str(original),repeat=row['path'],bitwise=equal,max_difference=maximum,
                    original_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),repeat_sha256=hashlib.sha256(Path(row['path']).read_bytes()).hexdigest(),metrics=row['full_metrics'])
        results.append(result);print('REPRODUCTION',seed,all(equal.values()),row['full_metrics']['rmse_mm'],flush=True)
    experiment.write(root/'reproduction_verification.json',dict(cuda=cuda,results=results,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))

if __name__=='__main__':main()
