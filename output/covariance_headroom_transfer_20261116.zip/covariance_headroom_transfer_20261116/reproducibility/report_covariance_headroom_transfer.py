"""Report no-retuning covariance transfer, N0/N1 effects and joint diagnostics."""
import csv
import hashlib
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from kroc.compare_covariance_headroom import ROOT,SEEDS,joint_metrics,audit

OUT=Path('kroc/reports/covariance_headroom_transfer_20261116')
BLUE='#2364AA';ORANGE='#D87924'
plt.rcParams.update({'font.size':10,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
KEYS=['rmse_mm','max_error_mm','jclip_nm_s','clip_steps','longest_clip_s','ess_mean','torque_rate_rms_nm_s','steady_rmse_mm','prediction_q_rmse_rad','prediction_dq_rmse_rad_s']


def write(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False))
def table(headers,rows):
    return ['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(map(str,row))+' |' for row in rows]+['']
def stats(rows):
    result=dict(n=len(rows),safe=sum(r['safe'] for r in rows),all_safe=all(r['safe'] for r in rows))
    result['mean']={k:float(np.mean([r['full_metrics'][k] for r in rows])) for k in KEYS}
    result['median']={k:float(np.median([r['full_metrics'][k] for r in rows])) for k in KEYS}
    result['sd']={k:float(np.std([r['full_metrics'][k] for r in rows],ddof=1)) for k in KEYS}
    for key in ['applied_rate_per_joint_nm_s','nominal_rate_per_joint_nm_s','compensation_rate_per_joint_nm_s','ik_configuration_deviation_rms_rad','velocity_rms_per_joint_rad_s']:
        if all('joints' in r for r in rows):result[key]=dict(mean=np.mean([r['joints'][key] for r in rows],0).tolist(),sd=np.std([r['joints'][key] for r in rows],0,ddof=1).tolist())
    return result

def changes(b,n):return {key:100*(n['mean'][key]/b['mean'][key]-1.) if b['mean'][key]>1e-10 else None for key in KEYS}
def save(fig,name):
    fig.savefig(OUT/(name+'.png'),dpi=240,bbox_inches='tight');fig.savefig(OUT/(name+'.svg'),bbox_inches='tight');plt.close(fig)
def f(v,d=3):return f'{v:.{d}f}'


def main():
    assert (ROOT/'completed.json').exists()
    OUT.mkdir(parents=True,exist_ok=True)
    rows=json.loads((ROOT/'progress.json').read_text());assert len(rows)==30
    plan=json.loads((ROOT/'plan.json').read_text())
    for name,digest in plan['source_sha256'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
    common={}
    for r in rows:
        with np.load(r['path']) as z:
            audit(z,r['spec'],r['case'])
            np.testing.assert_allclose(np.sqrt(np.mean(z['err_mm']**2)),r['full_metrics']['rmse_mm'],rtol=1e-12)
            for key in ['circle_reference','initial_q','d_true','sensor_noise_seed']:
                if r['seed'] in common:np.testing.assert_array_equal(z[key],common[r['seed']][key])
            common.setdefault(r['seed'],{key:z[key].copy() for key in ['circle_reference','initial_q','d_true','sensor_noise_seed']})
    grouped={name+'_'+case:stats([r for r in rows if r['setting']==name and r['case']==case]) for name,spec in plan['specifications'].items() for case in spec['cases']}
    comparisons={}
    for name in ['old_l1','new_l64']:
        pairs=[(next(r for r in rows if r['setting']==name and r['case']=='N0' and r['seed']==s),next(r for r in rows if r['setting']==name and r['case']=='N1' and r['seed']==s)) for s in SEEDS]
        comparisons[name]=dict(change_pct=changes(grouped[name+'_N0'],grouped[name+'_N1']),
            simultaneous_wins=sum(a['safe'] and b['safe'] and b['full_metrics']['rmse_mm']<a['full_metrics']['rmse_mm'] and b['full_metrics']['jclip_nm_s']<a['full_metrics']['jclip_nm_s'] for a,b in pairs),pairs=[dict(seed=a['seed'],n0=a,n1=b) for a,b in pairs])
    # Previously completed no-disturbance / DOB OFF data: reuse, do not rerun/select.
    previous=json.loads(Path('kroc/results/normalized_covariance_20261116/validation_progress.json').read_text())
    for r in previous:
        with np.load(r['path']) as z:r['joints']=joint_metrics(z)
    nominal={name:stats([r for r in previous if r['spec']['name']==name]) for name in ['baseline','s0.02_l64','s0.02_l1']}
    old=json.loads(Path('kroc/reports/input_headroom_final_20261115/analysis.json').read_text())['primary_pairs']
    combined={}
    for case in ['n0','n1']:
        earlier=[dict(p[case],safe=p['safe']) for p in old]
        fresh=[r for r in rows if r['setting']=='old_l1' and r['case']==case.upper()]
        combined[case]=stats(earlier+fresh)
    combined['change_pct']=changes(combined['n0'],combined['n1'])
    combined['simultaneous_wins']=sum(p['n1']['full_metrics']['rmse_mm']<p['n0']['full_metrics']['rmse_mm'] and p['n1']['full_metrics']['jclip_nm_s']<p['n0']['full_metrics']['jclip_nm_s'] for p in old)+comparisons['old_l1']['simultaneous_wins']
    cross_pairs=[]
    for seed in SEEDS:
        a=next(r for r in rows if r['setting']=='old_l1' and r['case']=='N0' and r['seed']==seed)
        b=next(r for r in rows if r['setting']=='new_l64' and r['case']=='N0' and r['seed']==seed)
        cross_pairs.append(dict(seed=seed,old=a,new=b,rmse_improved=b['full_metrics']['rmse_mm']<a['full_metrics']['rmse_mm']))
    result=dict(N0_transfer_pairs=cross_pairs,N0_transfer_rmse_wins=sum(p['rmse_improved'] for p in cross_pairs),groups=grouped,comparisons=comparisons,nominal_joint_groups=nominal,
        N0_new_vs_old_change_pct=changes(grouped['old_l1_N0'],grouped['new_l64_N0']),
        old_setting_combined15=combined,retuning=False,default_changed=False,
        limitations='Five fresh seeds, one sustained joint3 load; unsafe averages are diagnosis only, not valid improvement claims.')
    write(OUT/'analysis.json',result)
    with (OUT/'all_runs.csv').open('w',newline='') as stream:
        fields=['setting','case','seed','safe']+KEYS+[f'{kind}_j{j}' for kind in ['applied_rate','nominal_rate','ik_deviation'] for j in range(1,7)]
        writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
        for r in rows:
            values=dict(setting=r['setting'],case=r['case'],seed=r['seed'],safe=r['safe'],**{k:r['full_metrics'][k] for k in KEYS})
            for prefix,key in [('applied_rate','applied_rate_per_joint_nm_s'),('nominal_rate','nominal_rate_per_joint_nm_s'),('ik_deviation','ik_configuration_deviation_rms_rad')]:
                values.update({f'{prefix}_j{j+1}':v for j,v in enumerate(r['joints'][key])})
            writer.writerow(values)
    fig,axes=plt.subplots(2,2,figsize=(10,7),layout='constrained')
    for i,name in enumerate(['old_l1','new_l64']):
        pp=comparisons[name]['pairs']
        for ax,key,label in zip(axes[i],['rmse_mm','jclip_nm_s'],['EE RMSE [mm]','Clipping integral [Nm s]']):
            v=np.array([[p[c]['full_metrics'][key] for c in ['n0','n1']] for p in pp])
            for p,a in zip(pp,v):
                ax.plot([0,1],a,color='gray',alpha=.6)
                if name=='old_l1' and p['seed']==6307:ax.annotate('seed6307',(1,a[1]),xytext=(-65,-10),textcoords='offset points',fontsize=8)
            ax.scatter(np.zeros(5),v[:,0],color=BLUE);ax.scatter(np.ones(5),v[:,1],color=ORANGE)
            ax.errorbar([0,1],v.mean(0),yerr=v.std(0,ddof=1),fmt='D',color='black',capsize=4)
            ax.set(xticks=[0,1],xticklabels=['N0','N1'],ylabel=label,title=name+'; fresh n=5');ax.grid(axis='y',alpha=.2)
    save(fig,'fig01_fresh_n0_n1')
    fig,axes=plt.subplots(1,2,figsize=(11,4),layout='constrained')
    for ax,key,label in zip(axes,['rmse_mm','torque_rate_rms_nm_s'],['EE RMSE [mm]','Torque-rate RMS [Nm/s]']):
        names=['old_l1_N0','new_l1_N0','old_l64_N0','new_l64_N0'];v=[grouped[n]['mean'][key] for n in names];sd=[grouped[n]['sd'][key] for n in names]
        ax.bar(range(4),v,yerr=sd,capsize=4,color=[BLUE,'#5A91C4','#CBA16A',ORANGE]);ax.set(xticks=range(4),xticklabels=['Old cov\nlambda1','New cov\nlambda1','Old cov\nlambda64','New cov\nlambda64'],ylabel=label,title='N0 covariance x temperature; DOB+load ON');ax.grid(axis='y',alpha=.2)
    save(fig,'fig02_factorial_n0')
    fig,axes=plt.subplots(1,2,figsize=(11,4),layout='constrained')
    for name,color,offset,label in [('baseline',BLUE,-.17,'Old'),('s0.02_l64',ORANGE,.17,'Candidate')]:
        g=nominal[name]
        for ax,key,y in zip(axes,['applied_rate_per_joint_nm_s','ik_configuration_deviation_rms_rad'],['Applied torque-rate RMS [Nm/s]','IK configuration deviation RMS [rad]']):
            ax.bar(np.arange(1,7)+offset,g[key]['mean'],yerr=g[key]['sd'],width=.32,capsize=3,color=color,label=label);ax.set(xlabel='Joint index',ylabel=y,xticks=range(1,7));ax.grid(axis='y',alpha=.2);ax.legend()
    axes[0].set_title('Reused DOB OFF, no-load validation; n=5');axes[1].set_title('IK is not a commanded joint trajectory')
    save(fig,'fig03_nominal_joint_diagnostics')
    fig,axes=plt.subplots(2,2,figsize=(11,6),layout='constrained')
    for (name,case),color in zip([('old_l1','N0'),('old_l1','N1'),('new_l64','N0'),('new_l64','N1')],[BLUE,'#7FAAD2','#A45B1E',ORANGE]):
        row=next(r for r in rows if r['setting']==name and r['case']==case and r['seed']==6307)
        with np.load(row['path']) as z:
            t=np.arange(300)*.02;request=z['u_mppi']+z['d_hat_used']
            for ax,tt,a in [(axes[0,0],t+.02,z['err_mm']),(axes[0,1],t+.02,np.cumsum(np.linalg.norm(request-z['u_applied'],axis=1))*.02),(axes[1,0],t,request[:,2]),(axes[1,1],t,z['d_hat_used'][:,2]-z['d_true'][1:,2])]:ax.plot(tt,a,color=color,label=name+' '+case)
    axes[1,0].axhline(-150,color='black',ls='--',lw=1)
    for ax,y in zip(axes.flat,['EE error [mm]','Cumulative clipping [Nm s]','Requested torque3 [Nm]','DOB residual3 [Nm]']):ax.set(xlabel='Time [s]',ylabel=y);ax.grid(alpha=.2);ax.legend(fontsize=7)
    save(fig,'fig04_seed6307_diagnostic')
    build_report(plan,rows,grouped,comparisons,nominal,combined,result)
    write(ROOT/'integrity.json',dict(source_hashes_verified=True,paired_reference_disturbance_noise_verified=True,
        raw_audits_passed=True,raw_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*/*.npz')}))
    print('Report:',OUT)
    print(json.dumps({k:comparisons[k]['change_pct'] for k in comparisons},indent=2))


def build_report(plan,rows,groups,comparisons,nominal,combined,result):
    md=['# Covariance–temperature 외란 전이 및 N0/N1 비교','', '2026-11-16 | 후보 고정 · 비용 고정 · 새 seed5개 · GUI/기본값 미변경','',
        '## 실험 범위','',
        '새5개 seed6307/6317/6327/6337/6347에서 기존/후보 각각 N0/N1을20회 실행했다. N0 혼합 설정10회를 더해 covariance×temperature의2×2 대조도 완성했다. 별도 재현 확인2회를 포함해 총32회 CUDA 실행이다. 통계에는 주 비교30회만 사용하고 반복2회는 독립 표본으로 추가하지 않았다. 기존 무외란·DOB OFF의5개 seed는 관절별 분석에 재사용했다. 무외란 seed20–30개 확장은 수행하지 않았다. 현재 목적은 연구 외란에서의 전이와 N1 추가 효과 확인이며 후보를 다시 선택하지 않았다.','',
        '조건: 기존4cm/6s EE XY 원궤적, J3 -132.5Nm 부하를0.5–2.5초 raised-cosine 상승 후6초까지 유지. DOB Q3Hz, 센서 노이즈 ON. N0/N1은 같은 covariance·temperature·상태 비용을 쓰며 N1만 r=.95,w=10 접근 비용을 추가한다. Nominal rollout과 unbounded nominal 입력, 마지막 물리 clamp를 유지했다.','',
        '설정: old covariance=diag[13.6,23.8,13.6,2.72,2.72,.85], new covariance=diag[9,9,9,.3136,.3136,.3136]. old_l1이 이전 논문 보고서 설정이며 new_l64가 이번 후보다. 이전 무외란 확인의 RMSE 감소4.876%는5% 채택 기준에 근소 미달했으므로 후보는 탐색적 평가 대상이다.','',
        '## 새 seed 결과: N0/N1 효과','']
    md+=['**중요 판정:** 새 후보의 N0는 평균 오차·clipping·토크 변화율과 큰 오차의 seed 민감도를 줄였다. 그러나 후보 N1은 N0보다 clipping 손실만 줄였고 RMSE는5개 seed 모두 소폭 증가했다. 기존 설정 N1도 새5개에서 큰 악화가 발생했다. 따라서 이전10개 seed의 동시 개선을 일반적인 추종 성능 이점으로 제시하는 논문 결론은 수정해야 한다.','']
    md+=table(['설정','안전 검사','RMSE 평균±SD [mm]','중앙값 RMSE','Jclip 평균 [Nm·s]','ESS 평균','Rate 평균 [Nm/s]'],[[name,f"{g['safe']}/{g['n']}",f"{g['mean']['rmse_mm']:.3f}±{g['sd']['rmse_mm']:.3f}",f(g['median']['rmse_mm']),f(g['mean']['jclip_nm_s']),f(g['mean']['ess_mean'],2),f(g['mean']['torque_rate_rms_nm_s'],2)] for name,g in groups.items()])
    for name in ['old_l1','new_l64']:
        comp=comparisons[name];b=groups[name+'_N0'];n=groups[name+'_N1'];ch=comp['change_pct']
        md += [f"**{name}:** N1의 N0 대비 평균 RMSE 변화={ch['rmse_mm']:+.1f}%, Jclip 변화={ch['jclip_nm_s']:+.1f}%. 두 지표 동시 개선={comp['simultaneous_wins']}/5쌍. 전체 안전 쌍 여부={b['all_safe'] and n['all_safe']}.",'']
    md+=['평균±SD는 실행별 지표의 평균과 표본 SD다. 안전 검사란 평가한 q/dq 물리 한계와5ms 보간 mesh 접촉 검사의 통과를 뜻하며, 안정성 보장이나 좋은 추종 성능을 뜻하지 않는다. 실패 실행이 포함된 군의 전체 평균은 진단용이며 성공 성능으로 채택하지 않는다.','',
        '![Fresh pairs](fig01_fresh_n0_n1.png)','',
        'Figure1. 새5개 seed의 paired N0/N1 비교. 회색 선은 동일 seed를 연결하고 검은 점은 평균±SD다. 원자료의 큰 오차를 제외하거나 축 밖으로 숨기지 않았다.','',
        '## 기존 결과의 재현성 재평가','',
        '기존10개 seed에서는 N1이 모두 RMSE와 Jclip을 줄였다. 이번 새 seed6307의 큰 오차는 그 검증 범위를 넘어선 예외다. 설정이나 seed를 바꾸어 삭제하지 않았다. 기존10개와 이번5개를 합친 같은 old_l1 설정의15개 seed 통계도 아래에 공개한다. 새5개 독립 검증의 결과와 합친 통계를 구분해야 한다.','']
    md+=table(['old_l1 통합15개','N0','N1'],[[label,f(combined['n0']['mean'][key]),f(combined['n1']['mean'][key])] for key,label in [('rmse_mm','RMSE 평균 [mm]'),('max_error_mm','최대오차 평균 [mm]'),('jclip_nm_s','Jclip 평균 [Nm·s]')]])
    md += [f"통합15개에서 동시 개선은 {combined['simultaneous_wins']}/15쌍이지만, N1 평균 RMSE 변화={combined['change_pct']['rmse_mm']:+.1f}%, Jclip 변화={combined['change_pct']['jclip_nm_s']:+.1f}%다. 소수의 큰 악화까지 포함하면 평균 이점이 유지되지 않는다. 이전 보고서의10개 seed 결과는 해당 집합의 관측값으로 보존하되, 전체 seed에서 일관된 이점으로 일반화하지 않는다.",'',
        '![Outlier time diagnostic](fig04_seed6307_diagnostic.png)','',
        'Figure4. seed6307의 기존/후보 N0/N1 시간 응답. 동일 참조·참 외란·센서 seed를 사용했다. DOB 잔차는 폐루프 상태에 따라 달라질 수 있다. seed6307의 기존 N1은 요청 토크가 -150Nm 하한을 크게 초과하는 구간과 큰 EE 오차가 함께 나타나며, 부하 유지 구간 DOB 잔차는 상대적으로 작다. 포화 이후의 nominal 예측 불일치와 폐루프 악화에 부합하지만, 이 그림만으로 가중치 집중이나 비용 하나를 유일한 원인이라고 단정하지 않는다.','',
        '## N0에서 covariance와 lambda의 분리','', '![Factorial N0](fig02_factorial_n0.png)','',
        'Figure2. 같은5개 seed에서 covariance와 lambda를2×2로 조합한 N0의 평균±SD다. 다른 변수는 고정했다. 새 후보 대 기존 N0 비교는 튜닝 전이 효과이며, 같은 설정의 N1 대 N0 비교가 접근 비용의 추가 효과다. 큰 부하에서의 영향은 무외란 결과와 구분한다.','']
    ch=result['N0_new_vs_old_change_pct'];md += [f"후보 N0 대 기존 N0: 평균 RMSE {ch['rmse_mm']:+.1f}%, Jclip {ch['jclip_nm_s']:+.1f}%, torque-rate {ch['torque_rate_rms_nm_s']:+.1f}%. RMSE가 개선된 쌍은 {result['N0_transfer_rmse_wins']}/5다. 평균과 중앙값 및 개별 seed를 함께 봐야 하며, 일부 큰 오차 억제가 평균 개선을 주도할 수 있다.",'',
        '## J6와 관절별 분석','',
        '아래 표는 기존 무외란·DOB OFF 독립5개 seed를 재분석한 실제 actuator 입력 torque-rate RMS다. 이 조건은 clipping이 없어 nominal MPPI 출력과 실제 입력의 rate가 같았다.','']
    b=nominal['baseline'];n=nominal['s0.02_l64']
    md+=table(['관절','기존 rate [Nm/s]','후보 rate [Nm/s]','변화율'],[[f'J{j+1}',f(b['applied_rate_per_joint_nm_s']['mean'][j],2),f(n['applied_rate_per_joint_nm_s']['mean'][j],2),f"{100*(n['applied_rate_per_joint_nm_s']['mean'][j]/b['applied_rate_per_joint_nm_s']['mean'][j]-1):+.1f}%"] for j in range(6)])
    md+=['외란·DOB ON의 J6 입력은 다음처럼 분리해 비교했다. 값은 새5개 seed 평균이다.','']
    md+=table(['설정','J6 nominal rate','J6 applied rate','J6 compensation rate'],[[name,f(groups[name]['nominal_rate_per_joint_nm_s']['mean'][5],2),f(groups[name]['applied_rate_per_joint_nm_s']['mean'][5],2),f(groups[name]['compensation_rate_per_joint_nm_s']['mean'][5],2)] for name in ['old_l1_N0','old_l1_N1','new_l64_N0','new_l64_N1']])
    md+=['![Joint diagnostics](fig03_nominal_joint_diagnostics.png)','',
        'Figure3. 관절별 실제 입력 rate와 기준 IK 해와의 구성 편차 RMS, 평균±SD. EE 위치만이 추종 목표이며 기준 IK는 관절 추종 목표가 아니다. 따라서 구성 편차를 joint tracking error 또는 joint 추종 성능 개선으로 주장하지 않는다. 무외란 EE RMSE 변화는1.408→1.340mm였다. 별도 step response나 추종 대역폭 실험은 수행하지 않았으므로 torque-rate 감소만으로 모든 동적 응답에 손실이 없다고 해석하지 않는다. 외란 조건의 nominal/actual/compensation rate와 IK 구성 편차는 all_runs.csv 및 analysis.json에 분리 보존했다.','',
        '## 해석 범위와 다음 판단','',
        '이 결과는 한 자세·하나의 지속 부하 프로파일에서의5개 새 seed 확인이다. 제거·회복, 빠른 ramp, 부호 반전 및 다른 관절로 일반화하지 않는다. 외란 보상은 현재 추정값으로 직접 더해지므로 작은 covariance가 외란132.5Nm 전체를 탐색해서 만들어야 하는 구조는 아니다. 작은 탐색 폭의 문제는 보상 잔차·모델 차이·포화 때문에 필요한 nominal 입력 조정을 찾는 능력이다.','',
        'lambda64에서는 동일 N1 비용의 가중치 분포 영향도 달라진다. 이번에는 r=.95,w=10을 고정했고 결과를 보고 재튜닝하지 않았다. 효과가 약하거나 악화하면 “비용 설계가 새 sampler에서도 항상 유효”하다고 주장할 수 없다. 새 N1 비용 튜닝은 별도의 예비/검증 분리를 요구한다. 이번5개 결과에 맞춰 즉시 가중치나 외란 크기를 바꾸어 성공 사례를 고르는 방식은 피해야 한다.','',
        '기존 확정 보고서나 GUI를 덮어쓰지 않았다. 기존 설정의 seed 예외와 후보의 장단점을 공개한 상태로 후속 판단한다. 안정성·recursive feasibility·입력 포화 방지 보장은 이 실험의 대상이 아니다.','',
        '## 실행별 결과','']
    verification=ROOT/'reproduction_verification.json'
    if verification.exists():
        proof=json.loads(verification.read_text())
        md+=['### 별도 재실행 확인','']
        for v in proof['results']:
            md += [f"seed{v['seed']} N1 재실행: q/dq/EE/입력/추정값/외란/참조의 bitwise 동일={all(v['bitwise'].values())}, RMSE={v['metrics']['rmse_mm']:.6f} mm. 같은 재실행 프로세스에서 과거 저장 seed와 새 큰 오차 seed를 모두 확인했다.",'']
    md+=table(['설정','Case','Seed','RMSE [mm]','Jclip [Nm·s]','검사'],[[r['setting'],r['case'],str(r['seed']),f(r['full_metrics']['rmse_mm']),f(r['full_metrics']['jclip_nm_s']),'PASS' if r['safe'] else 'FAIL'] for r in rows])
    md+=['## 재현 자료','',f'원자료 및 동결 소스: `{ROOT}`. plan.json은 실험 전 설정과 해시, progress.json은 모든 실행의 지표, integrity.json은 raw NPZ 해시다. all_runs.csv는 전체30회의 핵심/관절별 지표를 포함한다. 그림은 PNG/SVG로 제공한다.','']
    (OUT/'report.md').write_text('\n'.join(md))


if __name__=='__main__':main()
