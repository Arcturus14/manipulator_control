# 추가 검증 결과와 기존 결론 수정

report.md에 새5개 seed 비교, 기존15개 합산, N0 factorial 비교, J6 분석과 반복 확인을 정리했다.

중요: 이전10개 seed의 N1 추종 우위는 새5개 seed에서 일관되게 유지되지 않았다. 기존 설정15개 합산에서는 N1 평균 RMSE와 clipping 손실이 N0보다 커졌다. 이번 후보의 N1은 모든5개 seed에서 clipping 손실을 줄였지만 RMSE는 모두 소폭 증가했다. 이전 보고서의 긍정적 결과만으로 논문의 일반적인 추종 개선을 주장하면 안 된다.

주 비교30회와 재현 확인2회는 모두 CUDA에서 실행했다. 반복2회는 독립 표본 통계에 추가하지 않았다. 재현은 과거seed5307과 새 큰 오차seed6307의 N1으로, 상태/입력/추정값 등이 모두 bitwise 동일했다.

PNG/SVG 그림4개, 전체30회 all_runs.csv, analysis.json 및 reproducibility 자료를 제공한다. 원시 NPZ는 kroc/results/covariance_headroom_transfer_20261116에 있으며 패키지에 중복 포함하지 않았다. 기존 보고서·Base·GUI는 수정하지 않았다.
