# Figure 캡션과 발표 설명

## Figure 1. 제어 구조와 입력 접근 비용

논문용 캡션: N0와 N1은 동일한 nominal rollout, DOB 후보상, 물리 입력 clamp를 사용한다. N1만 요청 토크 v+d_hat에 대한 접근 비용을 rollout stage 비용에 더한다. r=.95에서 비용이 시작되고, 정규화된 요청 토크가 물리 한도에 도달하면 관절당 비용은 w다.

그림의 의미와 한계: 추정값의 사용 위치는 후보상과 비용이다. 동적 hard 입력 범위 또는 포화 방지 보장으로 설명하면 안 된다.

발표 설명: 모델을 바꾸지 않고, 외란 보상까지 더했을 때 실행하기 어려운 입력을 비용으로 덜 선호하게 합니다.

PNG: [fig01_method.png](figures/fig01_method.png) · SVG: [fig01_method.svg](figures/fig01_method.svg)

## Figure 2. 동일한 작업 장면과 검증 외란

논문용 캡션: 좌측은 반경 0.04 m, 주기 6 s의 수평 EE 위치 원궤적이다. 우측은 관절3의 부하 프로파일이다. 유지 부하는 0.5-2.5초 raised-cosine으로 증가해 종료까지 유지한다. 제거 프로파일은 3.5-5초에 감소하고 5-6초는 회복 평가 구간이다.

그림의 의미와 한계: 주파수 응답 전체나 임의 저주파 신호에 대한 검증이 아니다. 작은 부하는 -50 Nm, 인접 부하는 -131.5/-132/-133 Nm다.

발표 설명: 기준 제어기와 작업 장면은 그대로 두고, 부하 크기와 제거 여부만 바꿨습니다.

PNG: [fig02_protocol.png](figures/fig02_protocol.png) · SVG: [fig02_protocol.svg](figures/fig02_protocol.svg)

## Figure 3. 포화가 추종 병목인지 확인한 진단

논문용 캡션: 예비 seed5107, 관절3 -132.5 Nm에서 N0의 물리 clamp 실행과 clamp 제거 가상 플랜트를 비교했다. RMSE는 8.118→6.142 mm로 회복됐다. 정상 부하 구간에서 clipping 성분 RMS는 3.505 Nm, DOB 잔차 RMS는 .537 Nm였다. unclamped 실행은 실제 가능한 비교 제어기가 아니다.

그림의 의미와 한계: 최초 clipping 2.38초까지 두 실행의 입력과 상태는 bitwise 동일했다. FF+참 외란은 해당 기준 IK 경로에서 한도 이내였지만, 이것만으로 모든 상태에서의 실현 가능성을 보장하지 않는다.

발표 설명: 먼저 포화를 없앤 가상 진단에서 오차가 회복되는지 확인해, 단순히 외란이 커서 오차가 증가한 경우와 구분했습니다.

PNG: [fig03_bottleneck.png](figures/fig03_bottleneck.png) · SVG: [fig03_bottleneck.svg](figures/fig03_bottleneck.svg)

## Figure 4. 예비 seed의 15개 비용 설정과 선정

논문용 캡션: 각 패널은 r=.85/.90/.95, 점 표기는 w=.3/1/3/10/30이다. 별은 N0다. 접촉·상태 위반 없이 RMSE5% 및 clipping 적분10% 이상을 함께 줄인 후보 중 RMSE 우선으로 r=.95,w=10을 선정했다. 이 조건은 예비 seed에서 RMSE6.803 mm, Jclip2.679 Nm·s였다.

그림의 의미와 한계: 전역 최적 파라미터가 아니다. r 변화는 시작 경계뿐 아니라 정규화 분모와 비용 기울기도 바꾼다. 모든 확인 결과에서 재선정하지 않았다.

발표 설명: 비용이 세질수록 항상 좋아지지는 않았습니다. 예비 seed에서 두 지표를 함께 줄이는 설정을 고정한 뒤 새 seed로 넘어갔습니다.

PNG: [fig04_pilot_selection.png](figures/fig04_pilot_selection.png) · SVG: [fig04_pilot_selection.svg](figures/fig04_pilot_selection.svg)

## Figure 5. 고정 부하의 최종 10개 paired seed

논문용 캡션: 유지 부하 -132.5 Nm에서 각 회색 선은 같은 seed의 N0와 N1을 연결한다. 색 점은 개별 실행, 검은 다이아몬드와 error bar는 평균±표본 SD다. 동시 개선은 10/10쌍이었다. SD는 신뢰구간이 아니다.

그림의 의미와 한계: 평균 비율은 실행별 평균들의 비율이다. 시간 샘플을 독립 표본으로 늘리지 않았다. 특정 부하·장면에서의 조건부 결과다.

발표 설명: 최종10개 seed에서 평균 RMSE 변화는 -23.4%, clipping 적분 변화는 -66.7%입니다.

PNG: [fig05_primary_paired.png](figures/fig05_primary_paired.png) · SVG: [fig05_primary_paired.svg](figures/fig05_primary_paired.svg)

## Figure 6. 추종·clipping·예측오차의 시간적 관계

논문용 캡션: 각 선은 primary10개 seed 평균, 음영은 최솟값~최댓값이다. 좌상은 EE 오차, 우상은 실행별 clipping 손실 norm의 누적 적분, 좌하는 요청 토크의 2.3-6초 확대, 우하는 1-step 관절 속도 예측오차 RMS다. 요청 시각은 k·dt, 상태오차는 다음 상태 시각에 표시했다.

그림의 의미와 한계: 1-step 오차에는 Euler rollout과 RK4 플랜트 차이, DOB 잔차가 함께 포함된다. 음영은 신뢰구간이 아니며, 입력을 한계에서 멀리 유지했다는 증거도 아니다.

발표 설명: 외란 상승 중 공통으로 남는 오차와, 부하 유지 후 포화 손실 때문에 커지는 오차를 구분해서 봐야 합니다.

PNG: [fig06_primary_time.png](figures/fig06_primary_time.png) · SVG: [fig06_primary_time.svg](figures/fig06_primary_time.svg)

## Figure 7. 파라미터를 고정한 인접 부하 검증

논문용 캡션: 모든 부하에서 동일한 새5개 seed와 r=.95,w=10을 사용했다. 원은 평균, error bar는 표본 SD다. Primary132.5 Nm도 비교 가능한 새5개만 표시했다. 안전하지 않은 부하군은 전체 성능선을 생략하고 표·부록에 실패 수를 공개한다.

그림의 의미와 한계: 진폭 외의 관절·부호·궤적·모델은 고정했다. 이 좁은 구간을 모든 외란으로 일반화할 수 없다.

발표 설명: 한 점의 최적화가 아니라 근처에서도 평균 이점이 유지되는지 확인했습니다. 개별 seed 악화와 효과 크기의 차이도 함께 공개합니다.

PNG: [fig07_adjacent_loads.png](figures/fig07_adjacent_loads.png) · SVG: [fig07_adjacent_loads.svg](figures/fig07_adjacent_loads.svg)

## Figure 8. 외란 감소와 제거 후 회복

논문용 캡션: 관절3 부하는 3.5초부터 감소해 5초에 0이 된다. 좌상은 참 외란과 추정값, 우상은 EE 오차, 좌하는 누적 clipping, 우하는 유지·제거·회복 구간별 RMSE 평균±SD다. 각 비교는 동일5개 새 seed로 수행했다.

그림의 의미와 한계: 구간 시작의 상태는 앞선 폐루프 제어의 결과여서 서로 다를 수 있다. 회복 차이는 DOB만의 차이나 제거 순간의 비용 효과만으로 해석하지 않는다. 평가 길이는 제거 후1초다.

발표 설명: 비용을 그대로 유지한 채 부하가 사라지는 구간도 확인했습니다. 완전 제거 후5-6초 RMSE 변화는 +2.8%입니다.

PNG: [fig08_removal.png](figures/fig08_removal.png) · SVG: [fig08_removal.svg](figures/fig08_removal.svg)

## Figure S1. 관절 구성 변화의 보조 평가

논문용 캡션: Primary10개 seed의 실제 관절과 기준 IK 해의 구성 편차 RMS 평균±SD다. N1이 모든 관절에서 더 작은 값을 갖는 것은 아니다. 기준 IK 해는 여러 가능한 해 중 하나이며 제어기의 관절 추종 목표가 아니다.

그림의 의미와 한계: 새로운 관절 궤적 추종 비용을 추가하거나 joint tracking 개선으로 주장하지 않았다.

발표 설명: 말단 위치를 개선하면서도 다른 관절 구성을 선택할 수 있으므로, 이 그림은 자세 변화의 보조 지표로만 사용합니다.

PNG: [figS1_joint_configuration.png](figures/figS1_joint_configuration.png) · SVG: [figS1_joint_configuration.svg](figures/figS1_joint_configuration.svg)
