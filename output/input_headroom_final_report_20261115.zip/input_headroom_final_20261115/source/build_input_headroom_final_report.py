"""Build the final Korean dossier/figure captions from completed frozen data."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from kroc.figures_input_headroom_final import OUT,OLD,NEW,load,stats


def p(text):return dict(type='paragraph',text=text)
def note(text):return dict(type='note',text=text)
def bullets(items):return dict(type='bullets',items=items)
def table(headers,rows,widths=None):return dict(type='table',headers=headers,rows=rows,widths=widths)
def equation(latex,plain,name):
    folder=OUT/'equations';folder.mkdir(exist_ok=True)
    fig=plt.figure(figsize=(10,.7));fig.text(.02,.45,'$'+latex+'$',fontsize=17,va='center')
    fig.savefig(folder/f'{name}.png',dpi=250,bbox_inches='tight',pad_inches=.08);plt.close(fig)
    return dict(type='equation',latex=latex,plain=plain,path=f'equations/{name}.png')
def figure(name,title,caption,talk,interpretation):
    return dict(type='figure',path=f'figures/{name}.png',vector=f'figures/{name}.svg',
                title=title,caption=caption,talk=talk,interpretation=interpretation)
def page(title,*blocks):return dict(title=title,blocks=list(blocks))
def fmt(v,digits=3):return f'{v:.{digits}f}'
def change(v):return '해당 없음' if v is None else f'{v:+.1f}%'
def mean_sd(s,case,key,digits=3):return f"{s[case]['mean'][key]:.{digits}f} ± {s[case]['sd'][key]:.{digits}f}"


def main():
    data=json.loads((OUT/'analysis.json').read_text());new,primary=load()
    s=data['primary'];groups=data['groups'];pages=[]
    primary_safe=s['all_safe']
    headline=(f"고정 조건의 10개 paired seed에서 RMSE {change(s['rmse_mm_change_pct'])}, clipping 적분 {change(s['jclip_nm_s_change_pct'])}. "
              f"동시 개선 {s['wins']}/{s['n']}, 접촉·상태 위반 없는 쌍 {s['safe']}/{s['n']}.")
    if not primary_safe:headline='전체 궤적 성능 평균은 실패 진단용이다. 안전하지 않은 실행이 포함되어 성공 주장으로 채택하지 않는다. '+headline
    adjacent_names=['adjacent_131p5','adjacent_132','adjacent_133']
    adjacent_all=all(groups[n]['all_safe'] for n in adjacent_names)
    control_pairs=[q for q in new['pairs'] if q['scenario'] in ['nominal','small_50']]
    control_equal=all(q['bitwise_equal'] for q in control_pairs)
    removal=[q for q in new['pairs'] if q['scenario']=='release_132p5']
    def window_mean(case,window,key):return float(np.mean([q[case]['windows'][window][key] for q in removal]))
    recovery_b=window_mean('n0','recovery','rmse_mm');recovery_n=window_mean('n1','recovery','rmse_mm')
    recovery_pct=100*(recovery_n/recovery_b-1.)
    # All confirmation outcomes are stated, including negative paired outcomes.
    release_pct=100*(window_mean('n1','release','rmse_mm')/window_mean('n0','release','rmse_mm')-1.)
    caveat=(f"부하 감소 구간 RMSE 변화는 {release_pct:+.1f}%, 완전 제거 후5-6초는 {recovery_pct:+.1f}%였다. "
            + ('소폭 악화되어 제거·회복 성능 개선은 주장하지 않는다.' if recovery_pct>0 else '이 확인만으로 일반적인 회복 개선을 주장하지 않는다.')
            + f" 제거 중 Jclip도 {window_mean('n0','release','jclip_nm_s'):.3f}→{window_mean('n1','release','jclip_nm_s'):.3f} Nm·s로 증가했다.")
    pages.append(page('01  연구 요약과 최종 판단',
        p('제안 주제: 외란 보상 토크를 고려한 입력 포화 접근 비용을 이용한 MPPI 추종 성능 개선'),
        note(headline),
        p('N1은 nominal rollout에 외란 추정값을 삽입하지 않는다. 보상 후 요청 토크에 soft 비용을 부과해 MPPI 샘플의 선호도를 바꾸고, 실제 입력에는 기존 물리 clamp를 유지한다. 목표는 포화 방지 보장이 아니라 포화로 인한 보상 손실과 추종오차의 동시 완화다.'),
        table(['10-seed primary 평균 ± 표본 SD','N0','N1'],[
            ['EE RMSE [mm]',mean_sd(s,'n0','rmse_mm'),mean_sd(s,'n1','rmse_mm')],
            ['Clipping 적분 [Nm·s]',mean_sd(s,'n0','jclip_nm_s'),mean_sd(s,'n1','jclip_nm_s')],
            ['최대 추종오차 [mm]',mean_sd(s,'n0','max_error_mm'),mean_sd(s,'n1','max_error_mm')],
            ['Torque-rate RMS [Nm/s]',mean_sd(s,'n0','torque_rate_rms_nm_s',2),mean_sd(s,'n1','torque_rate_rms_nm_s',2)]]),
        bullets([f"인접 부하 검증: 각 5개 seed. 전체 안전 쌍 여부={adjacent_all}. 개별 악화 사례까지 별도 공개한다.",
            f"무외란/작은 외란: 두 제어기의 상태·입력·추정값 bitwise 동일 여부={control_equal}.",caveat,
            '관절2·3 연구의 기존49회와 추가70회로 총119회 CUDA 실행을 보존했다. 추가70회에서는 r=.95,w=10과 Base를 고정하고 재튜닝하지 않았다.']),
        p('보고서 용도: 논문 작성의 실험 근거와 주제 발표 자료. 단일 UR5 시뮬레이션 장면의 조건부 성능 결과이며, 일반적 우월성·안전성·실시간 보장 또는 새로운 이론의 증명을 뜻하지 않는다.')))

    f1=figure('fig01_method','Figure 1. 제어 구조와 입력 접근 비용',
        'N0와 N1은 동일한 nominal rollout, DOB 후보상, 물리 입력 clamp를 사용한다. N1만 요청 토크 v+d_hat에 대한 접근 비용을 rollout stage 비용에 더한다. r=.95에서 비용이 시작되고, 정규화된 요청 토크가 물리 한도에 도달하면 관절당 비용은 w다.',
        '모델을 바꾸지 않고, 외란 보상까지 더했을 때 실행하기 어려운 입력을 비용으로 덜 선호하게 합니다.',
        '추정값의 사용 위치는 후보상과 비용이다. 동적 hard 입력 범위 또는 포화 방지 보장으로 설명하면 안 된다.')
    pages.append(page('02  문제 정의와 제안 방법',
        p('부호 정의: 외란 d는 인가 토크에서 차감된다. MPPI 출력 v에 DOB 추정값 d_hat을 더해 보상하지만, 합이 한도를 넘으면 요청한 입력이 일부 사라진다.'),
        equation(r'M(q)\ddot q+h(q,\dot q)=u_{\rm app}-d,\quad u_{\rm app}=\operatorname{clip}(v+\hat d)',
            'M(q) qdd + h(q, qd) = u_app - d; u_app = clip(v + d_hat)','plant'),
        equation(r'\ell_{\rm head}=w\sum_{j=1}^{6}\left(\frac{[|v_j+\hat d_j|-r_u\tau_{\max,j}]_+}{(1-r_u)\tau_{\max,j}}\right)^2',
            'headroom cost = w sum_j (positive_excess / ((1-r) limit))^2','cost'),
        f1,
        p('N0/N1 모두 nominal 입력 v의 고정 물리범위 clip을 제거했다. 기존 입력 크기·smoothness 비용은 같은 v 좌표와 계수로 유지했다. 마지막 실제 인가 입력의 clamp는 제거하지 않았다. d_hat은 한 solve 동안 horizon 전체에 고정하며 미래 외란 참값을 사용하지 않는다.')))

    f2=figure('fig02_protocol','Figure 2. 동일한 작업 장면과 검증 외란',
        '좌측은 반경 0.04 m, 주기 6 s의 수평 EE 위치 원궤적이다. 우측은 관절3의 부하 프로파일이다. 유지 부하는 0.5-2.5초 raised-cosine으로 증가해 종료까지 유지한다. 제거 프로파일은 3.5-5초에 감소하고 5-6초는 회복 평가 구간이다.',
        '기준 제어기와 작업 장면은 그대로 두고, 부하 크기와 제거 여부만 바꿨습니다.',
        '주파수 응답 전체나 임의 저주파 신호에 대한 검증이 아니다. 작은 부하는 -50 Nm, 인접 부하는 -131.5/-132/-133 Nm다.')
    pages.append(page('03  확정 Base와 재현 조건',
        table(['공통 항목','설정'],[
            ['dt / horizon / samples','0.02 s / 10 steps (0.2 s) / 136'],
            ['가중치 / 샘플링','exp(-rollout cost / 1); horizon 공유 Gaussian 노이즈'],
            ['Warm start / mean update','inverse-dynamics FF + residual / alpha=1'],
            ['비용','EE 1.2M, terminal 3.6M; q/dq 각각50k; smoothness .25'],
            ['상태·충돌','고정 full-span 마진2.5%; 충돌50k, clearance5mm'],
            ['DOB / 측정 노이즈','Q3Hz, 가속도 LPF OFF; q=.001rad, dq=.01rad/s'],
            ['물리 토크 한도 [Nm]','±[150,150,150,28,28,28]'],
            ['최종 접근 비용','r_u=.95; w=10; 관절별 물리 한도로 정규화']]),
        f2,
        p(f"초기 q [rad]: {[round(q,5) for q in data['initial_q']]}. 자세나 관절 궤적 추종 목표는 추가하지 않았다. noise variance=[13.6,23.8,13.6,2.72,2.72,.85]. 실행 기준은 동결 BoundaryPaperTracker이며 GUI 속도 최적화 경로의 timing과 혼합하지 않았다.")))

    f3=figure('fig03_bottleneck','Figure 3. 포화가 추종 병목인지 확인한 진단',
        '예비 seed5107, 관절3 -132.5 Nm에서 N0의 물리 clamp 실행과 clamp 제거 가상 플랜트를 비교했다. RMSE는 8.118→6.142 mm로 회복됐다. 정상 부하 구간에서 clipping 성분 RMS는 3.505 Nm, DOB 잔차 RMS는 .537 Nm였다. unclamped 실행은 실제 가능한 비교 제어기가 아니다.',
        '먼저 포화를 없앤 가상 진단에서 오차가 회복되는지 확인해, 단순히 외란이 커서 오차가 증가한 경우와 구분했습니다.',
        '최초 clipping 2.38초까지 두 실행의 입력과 상태는 bitwise 동일했다. FF+참 외란은 해당 기준 IK 경로에서 한도 이내였지만, 이것만으로 모든 상태에서의 실현 가능성을 보장하지 않는다.')
    pages.append(page('04  조건 선정과 포화 원인 진단',
        p('관절2·3의 N0 조건19개를 탐색했다. 짧은 clipping 조건인 관절2 -115 Nm와 관절3 -130 Nm는 unclamped 회복이 약1%여서 비용 튜닝 대상으로 채택하지 않았다. 경계를 한 차례 세분화한 뒤 관절3 -132.5 Nm를 선정했다.'),
        f3,
        note('선정 조건의 기준 FF+참 외란 토크 최솟값은 -149.47 Nm로 -150 Nm 한도 안에 있었다. 즉, 같은 EE 기준경로의 한 IK 해에는 입력 여지가 있었다. 실제 unclamped 궤적은 한도를 넘으므로 성능 비교나 실현 가능성 증명에 사용하지 않는다.'),
        p('더 큰 부하에서는 긴 포화 또는 접촉이 발생했다. 이 실패 실행도 원자료와 부록에 보존했으며 성공 조건의 평균에 섞지 않았다.')))

    f4=figure('fig04_pilot_selection','Figure 4. 예비 seed의 15개 비용 설정과 선정',
        '각 패널은 r=.85/.90/.95, 점 표기는 w=.3/1/3/10/30이다. 별은 N0다. 접촉·상태 위반 없이 RMSE5% 및 clipping 적분10% 이상을 함께 줄인 후보 중 RMSE 우선으로 r=.95,w=10을 선정했다. 이 조건은 예비 seed에서 RMSE6.803 mm, Jclip2.679 Nm·s였다.',
        '비용이 세질수록 항상 좋아지지는 않았습니다. 예비 seed에서 두 지표를 함께 줄이는 설정을 고정한 뒤 새 seed로 넘어갔습니다.',
        '전역 최적 파라미터가 아니다. r 변화는 시작 경계뿐 아니라 정규화 분모와 비용 기울기도 바꾼다. 모든 확인 결과에서 재선정하지 않았다.')
    pages.append(page('05  파라미터 선택과 데이터 분리',f4,
        table(['단계','데이터','역할'],[
            ['탐색·선정','seed5107; N0 19회, 진단5회, sweep15회','조건·가중치 선택에만 사용'],
            ['첫 독립 검증','5207/5217/5227/5237/5247','N0/N1 5쌍'],
            ['추가 확인','5307/5317/5327/5337/5347','7조건 ×5쌍 =70회'],
            ['Primary 최종 통계','기존5쌍+추가5쌍','서로 다른10개 seed; 파라미터 동일']]),
        p('무작위 seed는 MPPI 샘플링과 센서 노이즈를 바꾼다. 동일 seed 내 두 제어기는 초기 상태·참조·참 외란·노이즈 seed가 같다. 폐루프 궤적이 달라지면 측정 상태와 DOB 추정값은 달라질 수 있다. 독립 seed는 실제 하드웨어·모델 불확실성의 독립 실험을 의미하지 않는다.')))

    f5=figure('fig05_primary_paired','Figure 5. 고정 부하의 최종 10개 paired seed',
        f"유지 부하 -132.5 Nm에서 각 회색 선은 같은 seed의 N0와 N1을 연결한다. 색 점은 개별 실행, 검은 다이아몬드와 error bar는 평균±표본 SD다. 동시 개선은 {s['wins']}/{s['n']}쌍이었다. SD는 신뢰구간이 아니다.",
        f"최종10개 seed에서 평균 RMSE 변화는 {change(s['rmse_mm_change_pct'])}, clipping 적분 변화는 {change(s['jclip_nm_s_change_pct'])}입니다.",
        '평균 비율은 실행별 평균들의 비율이다. 시간 샘플을 독립 표본으로 늘리지 않았다. 특정 부하·장면에서의 조건부 결과다.')
    pages.append(page('06  핵심 결과: 손실과 추종의 동시 개선',f5,
        table(['평균 ± SD','N0','N1'],[[label,mean_sd(s,'n0',key,d),mean_sd(s,'n1',key,d)] for key,label,d in [
            ('rmse_mm','EE RMSE [mm]',3),('jclip_nm_s','Jclip [Nm·s]',3),
            ('max_error_mm','최대 EE 오차 [mm]',2),('longest_clip_s','최장 연속 clipping [s]',3),
            ('clip_steps','clipping step /300',1),('prediction_q_rmse_rad','1-step q RMSE [rad]',6),('prediction_dq_rmse_rad_s','1-step dq RMSE [rad/s]',5)]]),
        p(f"첫5개 seed의 RMSE 변화={change(data['first5']['rmse_mm_change_pct'])}, 추가5개={change(data['new5']['rmse_mm_change_pct'])}. 기존 결과를 본 뒤 추가 확인을 설계했으나, 파라미터·기준 제어기·대표 부하는 변경하지 않았다.")))

    f6=figure('fig06_primary_time','Figure 6. 추종·clipping·예측오차의 시간적 관계',
        '각 선은 primary10개 seed 평균, 음영은 최솟값~최댓값이다. 좌상은 EE 오차, 우상은 실행별 clipping 손실 norm의 누적 적분, 좌하는 요청 토크의 2.3-6초 확대, 우하는 1-step 관절 속도 예측오차 RMS다. 요청 시각은 k·dt, 상태오차는 다음 상태 시각에 표시했다.',
        '외란 상승 중 공통으로 남는 오차와, 부하 유지 후 포화 손실 때문에 커지는 오차를 구분해서 봐야 합니다.',
        '1-step 오차에는 Euler rollout과 RK4 플랜트 차이, DOB 잔차가 함께 포함된다. 음영은 신뢰구간이 아니며, 입력을 한계에서 멀리 유지했다는 증거도 아니다.')
    pages.append(page('07  개선 메커니즘과 남아 있는 오차',f6,
        p(f"98% 한계 접근률은 N0={100*s['n0']['mean']['near98_fraction']:.2f}%, N1={100*s['n1']['mean']['near98_fraction']:.2f}%였다. 필요한 한계 부근 입력을 계속 사용하면서 과도한 요청과 손실을 줄였다는 해석이 맞다."),
        p(f"Torque-rate RMS 평균은 {s['n0']['mean']['torque_rate_rms_nm_s']:.2f}→{s['n1']['mean']['torque_rate_rms_nm_s']:.2f} Nm/s, ESS 평균은 {s['n0']['mean']['ess_mean']:.3f}→{s['n1']['mean']['ess_mean']:.3f}였다. 기존의 집중된 샘플 가중치 구조는 그대로 유지했다.")))

    build_remaining(pages,data,new,primary,groups,removal,window_mean,recovery_pct)
    serialize(pages,data)
    print('Final report sources:',OUT)


def build_remaining(pages,data,new,primary,groups,removal,window_mean,recovery_pct):
    # Subsequent priorities, presentation guide, and appendices.
    f7=figure('fig07_adjacent_loads','Figure 7. 파라미터를 고정한 인접 부하 검증',
        '모든 부하에서 동일한 새5개 seed와 r=.95,w=10을 사용했다. 원은 평균, error bar는 표본 SD다. Primary132.5 Nm도 비교 가능한 새5개만 표시했다. 안전하지 않은 부하군은 전체 성능선을 생략하고 표·부록에 실패 수를 공개한다.',
        '한 점의 최적화가 아니라 근처에서도 평균 이점이 유지되는지 확인했습니다. 개별 seed 악화와 효과 크기의 차이도 함께 공개합니다.',
        '진폭 외의 관절·부호·궤적·모델은 고정했다. 이 좁은 구간을 모든 외란으로 일반화할 수 없다.')
    rows=[]
    for name,label in [('adjacent_131p5','-131.5'),('adjacent_132','-132.0'),('primary_132p5','-132.5'),('adjacent_133','-133.0')]:
        g=groups[name]
        rows.append([label,f"{g['wins']}/{g['n']}",f"{g['safe']}/{g['n']}",change(g['rmse_mm_change_pct']),change(g['jclip_nm_s_change_pct'])])
    pages.append(page('08  우선순위1: 인접 부하에서의 유지 범위',f7,
        table(['부하 [Nm]','동시 개선','안전 쌍','RMSE 변화','Jclip 변화'],rows),
        p('표의 변화율은 모든 쌍이 안전한 경우에만 성능 개선으로 해석한다. 개별 악화가 있으면 효과가 보장된다고 표현하지 않는다. 새5개 seed는 예비 선정에 사용하지 않았다.')))
    rows=[]
    for name,label in [('nominal','무외란'),('small_50','-50 Nm')]:
        g=groups[name];pp=[q for q in new['pairs'] if q['scenario']==name]
        rows.append([label,f"{g['n0']['mean']['rmse_mm']:.3f}",f"{g['n1']['mean']['rmse_mm']:.3f}",
            f"{g['n0']['mean']['jclip_nm_s']:.5f} / {g['n1']['mean']['jclip_nm_s']:.5f}",f"{sum(q['bitwise_equal'] for q in pp)}/5"])
    pages.append(page('09  우선순위2: 불필요한 성능 손실 확인',
        p('포화가 거의 없는 조건에서는 큰 개선보다 기존 동작을 불필요하게 바꾸지 않는지가 중요하다. 최종 r=.95,w=10을 그대로 사용해 무외란과 관절3 -50 Nm를 각각5개 seed로 비교했다.'),
        table(['조건','N0 RMSE [mm]','N1 RMSE [mm]','Jclip N0/N1','bitwise 동일'],rows),
        p('Bitwise 검사는 실제 q, dq, MPPI 명령, 인가 입력, DOB 추정값을 비교했다. 연산 시간은 서로 달라 비교 대상에서 제외했다. 입력 비용이 0인 조건에서 불필요한 제어 변화가 없는지 확인하는 재현 검사다.'),
        note('작은 외란에서도 개선돼야 한다는 목표를 두지 않았다. 이 대조 조건의 동등성은 지정된 자세·궤적·노이즈 범위에서 확인한 결과이며, 모든 무외란 작업에 대한 동등성 보장은 아니다.'),
        p('두 제어기는 모두 기존 nominal 입력 비용을 사용한다. N1만 후보상 포함 요청값을 추가 평가한다. 단순히 제어 입력의 에너지를 늘리거나 줄인 결과와 혼동하지 않도록 기존 비용계수는 유지했다.'),
        p('추가 일반화 항목으로는 다른 관절, 반대 부하 방향, 더 빠른 부하 변화, 다른 궤적과 자세, 모델 불일치가 남는다. 이번 최종 확인에서 이 항목들을 수행했다고 주장하지 않는다.')))

    f8=figure('fig08_removal','Figure 8. 외란 감소와 제거 후 회복',
        '관절3 부하는 3.5초부터 감소해 5초에 0이 된다. 좌상은 참 외란과 추정값, 우상은 EE 오차, 좌하는 누적 clipping, 우하는 유지·제거·회복 구간별 RMSE 평균±SD다. 각 비교는 동일5개 새 seed로 수행했다.',
        f"비용을 그대로 유지한 채 부하가 사라지는 구간도 확인했습니다. 완전 제거 후5-6초 RMSE 변화는 {recovery_pct:+.1f}%입니다.",
        '구간 시작의 상태는 앞선 폐루프 제어의 결과여서 서로 다를 수 있다. 회복 차이는 DOB만의 차이나 제거 순간의 비용 효과만으로 해석하지 않는다. 평가 길이는 제거 후1초다.')
    rows=[]
    for window,label in [('plateau','유지2.5-3.5s'),('release','제거3.5-5s'),('recovery','회복5-6s')]:
        rows.append([label,fmt(window_mean('n0',window,'rmse_mm')),fmt(window_mean('n1',window,'rmse_mm')),
            fmt(window_mean('n0',window,'jclip_nm_s')),fmt(window_mean('n1',window,'jclip_nm_s'))])
    pages.append(page('10  우선순위3: 제거·회복 시의 부작용',f8,
        table(['구간','N0 RMSE','N1 RMSE','N0 Jclip','N1 Jclip'],rows),
        p('RMSE 단위는 mm, Jclip 단위는 Nm·s다. 구간은 명령 시각 k·dt를 기준으로 나누고 해당 입력 이후 상태오차를 평가했다. 유지 부하 전체6초 결과와 제거 프로파일 결과는 합쳐 평균하지 않는다.'),
        note('제거 구간에는 Jclip도 0.088→0.392 Nm·s로 증가했다. 유지 구간의 개선이 제거·회복 구간까지 이어진다고 주장할 수 없다. 현재 추정값을 horizon에 고정하며 미래 제거 프로파일을 예측하지 않는다. 공통 DOB의 변화 추종 지연과 이전 상태 차이의 영향은 이번 비교에서 분리하지 않았다.')))

    g=data['primary'];b=g['n0']['mean'];n=g['n1']['mean']
    pages.append(page('11  논문에서의 주장과 선행연구 위치',
        note('허용되는 핵심 주장: DOB 후보상을 포함한 요청 토크의 포화 접근 비용은, 입력 포화가 추종 병목인 선택된 UR5 경계 부하 조건에서 nominal rollout을 유지하면서 clipping 손실과 EE 추종오차를 함께 줄였다.'),
        bullets(['추정 외란을 고려한 soft 비용의 시뮬레이션 설계·검증이 기여다. 최종 clamp와 같은 입력 한도로 비교했다.',
            '포화 방지, recursive feasibility, 안정성, 모든 외란의 우월성, 하드웨어 실시간 제어를 보장하지 않는다.',
            '같은 물리 모델을 플랜트·DOB가 공유한다. 모델 불일치, 액추에이터 지연·rate limit, 접촉력 기반 외란은 검증하지 않았다.',
            '포화 반영 rollout이나 동적 hard 입력 범위와의 성능 우열은 이번 N0/N1 비교만으로 판단할 수 없다.',
            'horizon 공유 노이즈와 rollout-cost-only 가중치를 쓰는 확정 구현이다. 표준 MPPI 이론 전체를 그대로 구현·증명했다고 표현하지 않는다.']),
        p('선행연구상 DOB와 총입력 제약을 함께 고려하는 아이디어 자체는 이미 존재한다. 따라서 “외란 추정으로 입력 제약을 고려한 최초 방법”이라는 신규성 주장은 하지 않는다. 본 비교의 차별점은 nominal rollout을 유지한 MPPI에서 후보상 포함 soft 비용을 분리 검증한 실험 설계와 결과다. 아래는 출판사 원문/초록으로 확인한 관련 자료이며, 투고 전 체계적 문헌 검토가 추가로 필요하다.'),
        table(['자료','확인한 내용 / 식별자'],[
            ['Williams, Aldrich, Theodorou (2017)','GPU 기반 MPPI 배경. JGCD40(2),344-357. DOI:10.2514/1.G001921'],
            ['Chen, Yang, Guo, Li (2016)','DOB 추정·보상 구조의 개요. IEEE TIE63(2),1083-1095. DOI:10.1109/TIE.2015.2478397'],
            ['Kong, Yuan (2019)','입력 제약을 다루는 DOB-fuzzy MPC. ISA Trans90,74-88. DOI:10.1016/j.isatra.2018.12.041'],
            ['Shimada (2023), Ch.9','보상 포함 입력 제약을 다루는 MPC 설명. DOI:10.1002/9781394178131.ch9']]),
        p('2015년 Abe 등의 time-varying constraints 논문은 Shimada 장의 참고문헌에서 확인했으며, 이번 작업에서 해당 논문 전문은 확보하지 않았다. 검토한 범위를 넘는 상세 알고리즘 비교는 하지 않는다.')))

    pages.append(page('12  주제 발표 구성과 예상 질문',
        p('권장 발표 길이6-8분. 문제→방법→원인 진단→독립 검증→동작 범위 순서로 구성한다. 모든 figure의 발표 문장은 별도 figure_captions.md에도 정리했다.'),
        table(['순서 / 시간','핵심 메시지','사용 그림'],[
            ['1 /45초','보상을 더한 총입력이 포화되면 계획한 입력이 사라진다.','F1'],
            ['2 /60초','모델은 그대로 두고 요청 토크 접근 비용만 추가한다.','F1·F2'],
            ['3 /60초','clipping이 추종 병목인 조건인지 먼저 진단했다.','F3'],
            ['4 /45초','예비 seed로 선택하고 검증 seed는 분리했다.','F4'],
            ['5 /90초','핵심 지표와 시간 응답을 함께 보여준다.','F5·F6'],
            ['6 /60초','인접 부하와 제거·회복의 결과/예외를 공개한다.','F7·F8'],
            ['7 /30초','조건부 기여와 아직 보장하지 않는 범위를 정리한다.','결론']]),
        bullets(['왜 clamp만으로 부족한가? 최종 한도는 지키지만, nominal rollout이 예상한 입력과 실제 입력의 차이를 최적화 단계에서 피하도록 유도하지 못한다.',
            '왜 rollout에 d_hat을 넣지 않는가? 후보상이 충분히 전달되는 경우를 기본 가정으로 두고, 총요청의 soft 비용 효과를 독립적으로 확인하기 위해서다.',
            '왜 한도 접근률은 그대로인가? 큰 지속 부하에서는 한도 근처 토크가 필요하다. 접근을 없애는 것과 초과 요청 손실을 줄이는 것은 다르다.',
            '왜 관절 궤적 오차가 모두 줄지 않는가? 제어 목표는 EE 위치이며 관절 구성은 달라질 수 있다. IK 해와의 차이를 별도 추종 실패로 해석하지 않는다.',
            '같은 조건에 과적합한 것은 아닌가? 예비/검증 seed를 분리했고, 파라미터 고정 후 인접 진폭·대조·제거 조건도 확인했다. 다만 검증 범위는 제한돼 있다.'])))

    f9=figure('figS1_joint_configuration','Figure S1. 관절 구성 변화의 보조 평가',
        'Primary10개 seed의 실제 관절과 기준 IK 해의 구성 편차 RMS 평균±SD다. N1이 모든 관절에서 더 작은 값을 갖는 것은 아니다. 기준 IK 해는 여러 가능한 해 중 하나이며 제어기의 관절 추종 목표가 아니다.',
        '말단 위치를 개선하면서도 다른 관절 구성을 선택할 수 있으므로, 이 그림은 자세 변화의 보조 지표로만 사용합니다.',
        '새로운 관절 궤적 추종 비용을 추가하거나 joint tracking 개선으로 주장하지 않았다.')
    pages.append(page('13  보조 지표와 평가식',f9,
        p('EE RMSE는 실행별 sqrt(mean(||p-p_ref||²)), 최대오차는 실행별 max(||p-p_ref||)다. 표의 평균±SD는 seed별 지표의 평균과 표본 표준편차다. Clipping step은 어느 관절이든 요청-인가 차이가1e-5 Nm를 넘는 step이며 최장 연속 시간은 연속 step 수×.02초다.'),
        p('Jclip은 dt×sum_k ||u_app-(v+d_hat)||₂이다. 한계 접근률은 어느 관절이든 |u_app|≥.98×limit인 step 비율이다. Torque-rate RMS는 모든 관절의 연속 인가 입력 차이를 dt로 나눈 값의 RMS다. 1-step 상태오차는 실제 상태에서 시작한 nominal Euler 예측과 다음 RK4 실제 상태 차이로 측정했다.'),
        p('접촉은5ms 보간 mesh 감사로 검사했다. q·dq 위반과 접촉이 있는 실행은 전체 궤적 성능 개선으로 채택하지 않는다. 공통 접촉 전 구간 지표와 전체 실패 지표를 함께 보존했다. Compile/warmup·offline 감사는 timing에서 제외하며, 모델에 연산 지연은 없다.')))

    allpairs=[dict(q,cohort='new') for q in new['pairs']]+[q for q in primary if q.get('cohort')=='first5']
    rows=[]
    labels={'adjacent_131p5':'A131.5','adjacent_132':'A132','adjacent_133':'A133','nominal':'Zero','small_50':'Small50','release_132p5':'Removal','primary_132p5':'Primary'}
    for q in sorted(allpairs,key=lambda q:(q['scenario'],q['seed'])):
        b,n=q['n0']['full_metrics'],q['n1']['full_metrics']
        rows.append([labels[q['scenario']],str(q['seed']),fmt(b['rmse_mm'],2),fmt(n['rmse_mm'],2),fmt(b['jclip_nm_s'],2),fmt(n['jclip_nm_s'],2),'OK' if q['safe'] else 'FAIL'])
    pages.append(page('14  부록: 전체 paired 확인 결과',
        p('원시 단위는 RMSE[mm], Jclip[Nm·s]. Primary는 기존5쌍과 새5쌍을 포함한다. 다른 각 조건은 새5쌍이다. Unsafe 실행의 전체 지표는 진단용이며 성공 평균으로 해석하지 않는다.'),
        table(['조건','Seed','RMSE0','RMSE1','Jclip0','Jclip1','검사'],rows),
        p('A=인접 부하 크기[Nm], Zero=무외란, Small50=-50Nm, Removal=제거 프로파일, Primary=-132.5Nm 유지. 모든 실제 비교는 물리 clamp를 유지했다.')))
    pages.append(page('15  재현 자료와 논문 작성 인계',
        table(['파일/폴더','내용'],[
            ['report.md / report_data.json','편집용 최종 보고서 / PDF 생성용 구조화 내용'],
            ['figures/*.png, *.svg','300dpi PNG 및 벡터 SVG; 그림 번호 고정'],
            ['figure_captions.md','논문용 캡션, 해석 범위, 발표 문장'],
            ['paired_results.csv / analysis.json','전체40쌍의 핵심 지표 및 세부 집계'],
            ['pilot_runs.csv','실패 포함 예비 탐색·진단·sweep39회의 지표'],
            ['references.bib','확인한 관련 문헌의 BibTeX'],
            ['원자료 root A','kroc/results/position_input_headroom_20261115'],
            ['원자료 root B','kroc/results/input_headroom_final_checks_20261115']]),
        p('단계별 manifest와 동결 소스, 원시 NPZ, JSON 지표, source/raw SHA256을 보존했다. 이전 예비·선정 데이터와 독립 확인 데이터를 구분하고, 실패 실행이나 개별 악화를 삭제하지 않았다. 원자료 전체를 보고서 패키지에 중복 복사하지 않았으며 저장소의 위 경로를 참조한다.'),
        bullets(['재현 실행: python -m kroc.final_input_headroom_checks --priority all (CUDA 필요; 기존 결과는 재사용).',
            '집계: python -m kroc.figures_input_headroom_final; python -m kroc.build_input_headroom_final_report.',
            'PDF: /usr/bin/python3 -m kroc.render_input_headroom_final_pdf. 테스트는 CPU 대수 검사이며 성능 실험은 CUDA만 사용했다.',
            '논문 초안은 문제/방법, 실험 설정, 예비 선정, 독립 검증, 강건성 확인, 한계 순서가 적절하다. 기존 MPPI·DOB/입력 제약 연구와의 신규성 검토를 완료한 것으로 간주하지 않는다.']),
        p('추천 결론 문장: “보상 후 총입력에 대한 포화 접근 비용을 nominal MPPI에 추가하여, 입력 포화가 추종 병목으로 작용하는 UR5 시뮬레이션 조건에서 clipping 손실과 EE 추종오차의 동시 개선을 확인하였다. 인접 부하 및 외란 제거 구간의 추가 결과는 검증 범위와 예외를 함께 제시하였다.”')))


def serialize(pages,data):
    document=dict(title='외란 보상 토크를 고려한 MPPI 입력 포화 접근 비용',subtitle='최종 실험 보고서 · 논문 작성 및 주제 발표용',date='2026-11-15',pages=pages)
    (OUT/'report_data.json').write_text(json.dumps(document,indent=2,ensure_ascii=False))
    md=['# '+document['title'],'',document['subtitle']+' | '+document['date'],''];captions=['# Figure 캡션과 발표 설명','']
    for page_data in pages:
        md+=['## '+page_data['title'],'']
        for block in page_data['blocks']:
            kind=block['type']
            if kind in ['paragraph','note']:md+=[('> ' if kind=='note' else '')+block['text'],'']
            elif kind=='bullets':md+=['- '+x for x in block['items']]+['']
            elif kind=='table':
                md+=['| '+' | '.join(block['headers'])+' |','| '+' | '.join(['---']*len(block['headers']))+' |']
                md+=['| '+' | '.join(str(v) for v in row)+' |' for row in block['rows']]+['']
            elif kind=='equation':md+=['\\[',block['latex'],'\\]','']
            elif kind=='figure':
                md+=['### '+block['title'],'',f"![{block['title']}]({block['path']})",'',block['caption'],'',
                    '**해석:** '+block['interpretation'],'','**발표 설명:** '+block['talk'],'']
                captions+=['## '+block['title'],'','논문용 캡션: '+block['caption'],'',
                    '그림의 의미와 한계: '+block['interpretation'],'','발표 설명: '+block['talk'],'',
                    f"PNG: [{Path(block['path']).name}]({block['path']}) · SVG: [{Path(block['vector']).name}]({block['vector']})",'']
    md+=['## 참고문헌과 확인 범위','',
        'MPPI의 GPU 샘플링 기반 최적화 배경: [Williams et al. (2017)](https://doi.org/10.2514/1.G001921).',
        '', 'DOB 추정·보상 기법의 배경: [Chen et al. (2016)](https://doi.org/10.1109/TIE.2015.2478397).',
        '', '입력 제약을 포함한 DOB-MPC 선행연구: [Kong and Yuan (2019)](https://doi.org/10.1016/j.isatra.2018.12.041).',
        '', '보상 포함 입력 제약의 설명: [Shimada (2023), Ch.9](https://onlinelibrary.wiley.com/doi/10.1002/9781394178131.ch9). 출판사 공개 초록·요약/참고문헌을 확인했으며 관련 논문 전부의 전문 검토를 수행한 것은 아니다.','']
    (OUT/'report.md').write_text('\n'.join(md));(OUT/'figure_captions.md').write_text('\n'.join(captions))
    (OUT/'references.bib').write_text('''@article{williams2017mppi,
 author={Grady Williams and Andrew Aldrich and Evangelos A. Theodorou},
 title={Model Predictive Path Integral Control: From Theory to Parallel Computation},
 journal={Journal of Guidance, Control, and Dynamics}, year={2017}, volume={40}, number={2}, pages={344--357}, doi={10.2514/1.G001921}}
@article{chen2016dob,
 author={Wen-Hua Chen and Jun Yang and Lei Guo and Shihua Li},
 title={Disturbance-Observer-Based Control and Related Methods: An Overview},
 journal={IEEE Transactions on Industrial Electronics}, year={2016}, volume={63}, number={2}, pages={1083--1095}, doi={10.1109/TIE.2015.2478397}}
@article{kong2019dobmpc,
 author={Lei Kong and Jingqi Yuan}, title={Disturbance-observer-based fuzzy model predictive control for nonlinear processes with disturbances and input constraints},
 journal={ISA Transactions}, year={2019}, volume={90}, pages={74--88}, doi={10.1016/j.isatra.2018.12.041}}
@incollection{shimada2023mpcdob,
 author={Akira Shimada}, title={Model Predictive Control with DOB},
 booktitle={Disturbance Observer for Advanced Motion Control with MATLAB/Simulink}, year={2023}, chapter={9}, doi={10.1002/9781394178131.ch9}}
''')


if __name__=='__main__':main()
