"""Verify frozen experiments and delivered report metrics without rerunning plants."""
import hashlib
import json
from pathlib import Path
import numpy as np
from kroc.final_input_headroom_checks import ROOT,PREVIOUS,pair_rows
from kroc.position_input_headroom_study import audit,metrics

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    manifest=json.loads((ROOT/'manifest.json').read_text())
    for path,value in manifest['source_sha256'].items():assert sha(path)==value,path
    old=json.loads((PREVIOUS/'integrity.json').read_text())
    for path,value in old['raw_sha256'].items():assert sha(PREVIOUS/path)==value,path
    summary=json.loads((ROOT/'summary.json').read_text());assert summary['completed_runs']==70
    assert len(summary['pairs'])==35
    rows=[json.loads(f.read_text()) for scenario in manifest['scenarios'] for f in (ROOT/scenario).glob('*.json')]
    assert len(rows)==70
    for row in rows:
        assert row['fraction']==.95 and row['weight']==(10. if row['case']=='N1' else 0.)
        with np.load(row['path']) as z:
            audit(z,row['case'],False)
            computed=metrics(z)
            for key,value in row['full_metrics'].items():
                np.testing.assert_allclose(computed[key],value,atol=1e-9,rtol=1e-9,err_msg=row['path']+key)
    pairs=pair_rows(rows);assert len(pairs)==35
    result=dict(completed_runs=70,paired_checks=35,source_hashes_verified=True,prior_raw_hashes_verified=True,
        metrics_recomputed=True,reference_disturbance_noise_pairing_verified=True,
        fixed_parameters_verified=True,unit_tests='26 unittest checks passed',
        all_pairs_safe=all(p['safe'] for p in pairs),
        raw_sha256={str(p.relative_to(ROOT)):sha(p) for p in sorted(ROOT.glob('*/*.npz'))},
        report_source_sha256={str(p):sha(p) for p in map(Path,[
            'kroc/figures_input_headroom_final.py','kroc/build_input_headroom_final_report.py',
            'kroc/render_input_headroom_final_pdf.py','kroc/audit_final_input_headroom_report.py',
            'kroc/test_final_input_headroom_checks.py'])})
    (ROOT/'integrity.json').write_text(json.dumps(result,indent=2,allow_nan=False))
    print({k:v for k,v in result.items() if not k.endswith('sha256')})

if __name__=='__main__':main()
