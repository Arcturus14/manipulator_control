"""Render the frozen Korean report, using system ReportLab only."""
import json
from pathlib import Path
from html import escape
from PIL import Image as PILImage
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle, PageBreak, KeepTogether

ROOT=Path('kroc/reports/input_headroom_final_20261115')
OUTPUT=Path('output/pdf/input_headroom_final_report_20261115.pdf')
BLUE=colors.HexColor('#17436B');GRAY=colors.HexColor('#546472')
pdfmetrics.registerFont(TTFont('Nanum','/usr/share/fonts/truetype/nanum/NanumGothic.ttf'))
pdfmetrics.registerFont(TTFont('NanumBold','/usr/share/fonts/truetype/nanum/NanumGothicBold.ttf'))
pdfmetrics.registerFontFamily('Nanum',normal='Nanum',bold='NanumBold',italic='Nanum',boldItalic='NanumBold')
STYLES={
 'body':ParagraphStyle('body',fontName='Nanum',fontSize=9,leading=13,spaceAfter=7,wordWrap='CJK'),
 'title':ParagraphStyle('title',fontName='NanumBold',fontSize=17,leading=23,textColor=BLUE,spaceAfter=13,wordWrap='CJK'),
 'small':ParagraphStyle('small',fontName='Nanum',fontSize=7.7,leading=11,textColor=GRAY,spaceAfter=6,wordWrap='CJK'),
 'caption':ParagraphStyle('caption',fontName='Nanum',fontSize=8,leading=11.5,spaceAfter=5,wordWrap='CJK'),
 'figure':ParagraphStyle('figure',fontName='NanumBold',fontSize=9,leading=13,textColor=BLUE,spaceAfter=3,wordWrap='CJK'),
 'table':ParagraphStyle('table',fontName='Nanum',fontSize=7.7,leading=10.5,wordWrap='CJK'),
 'header':ParagraphStyle('header',fontName='NanumBold',fontSize=7.7,leading=10.5,textColor=colors.white,wordWrap='CJK'),
}

def para(text,kind='body'):
    return Paragraph(escape(str(text)),STYLES[kind])

def picture(path,width=495,maxheight=310):
    w,h=PILImage.open(path).size
    scale=min(width/w,maxheight/h)
    return Image(str(path),width=w*scale,height=h*scale,hAlign='CENTER')

def make_table(b):
    rows=[b['headers']]+b['rows'];n=len(rows[0]);total=495
    widths=b.get('widths')
    if widths:widths=[total*x/sum(widths) for x in widths]
    elif n==2:widths=[total*.33,total*.67]
    elif n==3:widths=[total*.42,total*.29,total*.29]
    else:widths=[total/n]*n
    small=len(rows)>30
    if small:
        style=ParagraphStyle('dense',parent=STYLES['table'],fontSize=7,leading=8.6)
        cells=[[Paragraph(escape(str(v)),STYLES['header'] if i==0 else style) for v in row] for i,row in enumerate(rows)]
    else:cells=[[para(v,'header' if i==0 else 'table') for v in row] for i,row in enumerate(rows)]
    t=Table(cells,colWidths=widths,repeatRows=1,hAlign='LEFT')
    pad=2.5 if small else 5
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),BLUE),('VALIGN',(0,0),(-1,-1),'TOP'),
        ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F1F5F8')]),
        ('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),
        ('TOPPADDING',(0,0),(-1,-1),pad),('BOTTOMPADDING',(0,0),(-1,-1),pad),
        ('LINEBELOW',(0,-1),(-1,-1),.4,colors.HexColor('#CDD7DF'))]))
    return t

def footer(canvas,doc):
    canvas.saveState();w,h=A4
    canvas.setStrokeColor(colors.HexColor('#D6DEE5'));canvas.line(42,39,w-42,39)
    canvas.setFont('Nanum',7);canvas.setFillColor(GRAY)
    canvas.drawString(42,27,'MPPI / DOB input headroom | frozen confirmation report | 2026-11-15')
    canvas.drawRightString(w-42,27,str(doc.page));canvas.restoreState()

def main():
    data=json.loads((ROOT/'report_data.json').read_text());OUTPUT.parent.mkdir(parents=True,exist_ok=True)
    story=[]
    for i,page in enumerate(data['pages']):
        if i:story.append(PageBreak())
        story.append(para(page['title'],'title'))
        if i==0:story.append(para(data['subtitle']+' | '+data['date'],'small'))
        for b in page['blocks']:
            kind=b['type']
            if kind=='paragraph':story.append(para(b['text']))
            elif kind=='note':
                box=Table([[para(b['text'])]],colWidths=[495]);box.setStyle(TableStyle([
                    ('BACKGROUND',(0,0),(-1,-1),colors.HexColor('#EBF2F8')),
                    ('BOX',(0,0),(-1,-1),.5,colors.HexColor('#BDCEDD')),
                    ('LEFTPADDING',(0,0),(-1,-1),9),('RIGHTPADDING',(0,0),(-1,-1),9),
                    ('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),3)]))
                story.extend([box,Spacer(1,8)])
            elif kind=='bullets':
                for text in b['items']:story.append(para('• '+text))
            elif kind=='table':story.extend([make_table(b),Spacer(1,9)])
            elif kind=='equation':story.extend([picture(ROOT/b['path'],maxheight=48),Spacer(1,8)])
            elif kind=='figure':
                content=[para(b['title'],'figure'),picture(ROOT/b['path']),Spacer(1,4),para(b['caption'],'caption')]
                story.append(KeepTogether(content));story.append(para('해석: '+b['interpretation'],'small'))
                story.append(para('발표 설명: '+b['talk'],'small'))
    doc=SimpleDocTemplate(str(OUTPUT),pagesize=A4,rightMargin=50,leftMargin=50,topMargin=42,bottomMargin=50,
        title=data['title'],author='Manipulator Control Research',pageCompression=1)
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    print(OUTPUT)

if __name__=='__main__':main()
