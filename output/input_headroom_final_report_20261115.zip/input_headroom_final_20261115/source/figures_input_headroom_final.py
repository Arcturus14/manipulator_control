"""Publication assets from frozen pilot/confirmation data; no simulations."""
import csv
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from config import DT

OLD=Path('kroc/results/position_input_headroom_20261115')
NEW=Path('kroc/results/input_headroom_final_checks_20261115')
OUT=Path('kroc/reports/input_headroom_final_20261115')
BLUE='#2364AA';ORANGE='#D87924';GRAY='#62717D';PURPLE='#7354A3'
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,
    'svg.fonttype':'none','savefig.facecolor':'white','axes.titleweight':'bold'})


def load():
    new=json.loads((NEW/'summary.json').read_text())
    if new['completed_runs']!=70:raise RuntimeError('Do not publish a partial confirmation report')
    old=json.loads((OLD/'validation_summary.json').read_text())
    pairs=[dict(p,scenario='primary_132p5',safe=p['usable'],cohort='first5') for p in old['pairs']]
    pairs += [dict(p,cohort='new5') for p in new['pairs'] if p['scenario']=='primary_132p5']
    return new,pairs


def stats(pairs):
    result={'n':len(pairs),'safe':sum(p['safe'] for p in pairs),'all_safe':all(p['safe'] for p in pairs)}
    result['wins']=sum(p['safe'] and p['n1']['full_metrics']['rmse_mm']<p['n0']['full_metrics']['rmse_mm']
        and p['n1']['full_metrics']['jclip_nm_s']<p['n0']['full_metrics']['jclip_nm_s'] for p in pairs)
    for case in ['n0','n1']:
        metrics=[p[case]['full_metrics'] for p in pairs]
        keys=[k for k,v in metrics[0].items() if isinstance(v,(int,float))]
        result[case]={'mean':{k:float(np.mean([m[k] for m in metrics])) for k in keys},
            'sd':{k:float(np.std([m[k] for m in metrics],ddof=1)) if len(metrics)>1 else 0. for k in keys}}
    for metric in ['rmse_mm','jclip_nm_s']:
        b=result['n0']['mean'][metric];n=result['n1']['mean'][metric]
        result[metric+'_change_pct']=None if b<=1e-10 else 100*(n/b-1.)
    return result


def save(fig,name):
    folder=OUT/'figures';folder.mkdir(parents=True,exist_ok=True)
    fig.savefig(folder/f'{name}.png',dpi=300,bbox_inches='tight')
    fig.savefig(folder/f'{name}.svg',bbox_inches='tight');plt.close(fig)


def style(ax,xlabel,ylabel):
    ax.set(xlabel=xlabel,ylabel=ylabel);ax.grid(alpha=.2)


def architecture():
    fig,(ax,curve)=plt.subplots(1,2,figsize=(12,4.4),gridspec_kw={'width_ratios':[3.5,1.25]},layout='constrained')
    ax.set(xlim=(0,12),ylim=(0,5));ax.axis('off')
    def box(x,y,w,h,text,color='#F0F4F8'):
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.08',facecolor=color,edgecolor=GRAY))
        ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=9)
    def arrow(a,b,color=GRAY,ls='-'):
        ax.annotate('',xy=b,xytext=a,arrowprops={'arrowstyle':'->','color':color,'lw':1.5,'linestyle':ls})
    box(.2,2.6,2.4,1.2,'MPPI\nnominal rollout: f(x, v)')
    box(3.5,2.8,1.2,.8,'v + d_hat')
    box(5.5,2.8,1.4,.8,'Actuator\nclamp')
    box(8,2.6,2.2,1.2,'UR5 plant\napplied torque - d')
    box(8,.35,2.2,1.1,'DOB\nmeasured state\n+ applied torque')
    box(3.2,.35,3.5,1.1,'Headroom cost phi(v + d_hat)\nN0: OFF / N1: ON','#FFF1E2')
    arrow((2.6,3.2),(3.5,3.2));arrow((4.7,3.2),(5.5,3.2));arrow((6.9,3.2),(8,3.2))
    arrow((9.1,2.6),(9.1,1.45));arrow((8,.9),(6.7,.9),ORANGE)
    arrow((4.1,2.8),(4.1,1.45),ORANGE);arrow((3.2,.9),(1.4,.9),ORANGE)
    arrow((1.4,.9),(1.4,2.6),ORANGE)
    arrow((8.1,1.35),(4.65,2.85),GRAY,'--')
    ax.text(6.4,2.,'same causal d_hat',fontsize=8,color=GRAY)
    ax.text(6.2,4.25,'Physical command limit is identical in N0 and N1',ha='center',fontsize=10)
    ax.text(6.,-.02,'d_hat is used in compensation and cost; it is NOT inserted into the N1 rollout.',ha='center',fontsize=9,color=ORANGE)
    a=np.linspace(0,1.08,350);r=.95
    curve.plot(a,np.maximum(a-r,0.)**2/(1-r)**2,color=ORANGE,lw=2)
    curve.axvline(r,color=GRAY,ls=':',label='r = 0.95');curve.axvline(1.,color=GRAY,ls='--',label='physical limit')
    style(curve,'|requested torque| / limit','phi / w');curve.set_title('Soft cost');curve.legend(fontsize=8)
    save(fig,'fig01_method')


def scenario():
    with np.load(OLD/'validation/j3_a-132.5_N0_r0.95_w0_s5207.npz') as z:
        reference=z['circle_reference'];q0=z['initial_q'].copy()
    fig,(ax,b)=plt.subplots(1,2,figsize=(11,4.3),layout='constrained')
    ax.plot(reference[:,0],reference[:,1],color=BLUE,lw=2);ax.scatter(*reference[0,:2],color=ORANGE,label='start')
    ax.set_aspect('equal');style(ax,'X [m]','Y [m]');ax.set_title('EE position reference: 4 cm circle');ax.legend()
    t=np.arange(300)*DT;up=.5*(1-np.cos(np.pi*np.clip((t-.5)/2.,0,1)))
    down=.5*(1+np.cos(np.pi*np.clip((t-3.5)/1.5,0,1)))
    b.plot(t,-132.5*up,color=GRAY,label='held -132.5 Nm')
    b.plot(t,-132.5*up*down,color=PURPLE,ls='--',label='removal profile')
    b.plot(t,-50*up,color='gray',ls=':',label='small -50 Nm')
    b.axhline(0,color='lightgray');b.axvspan(.5,2.5,color='gray',alpha=.08)
    b.axvspan(3.5,5.,color=PURPLE,alpha=.07);style(b,'Time [s]','True joint3 disturbance [Nm]')
    b.legend(fontsize=8);b.set_title('Fixed scene; only load profile varies')
    save(fig,'fig02_protocol');return q0.tolist()


def diagnostic():
    c=json.loads((OLD/'condition_selection.json').read_text())['selected']
    fig,axes=plt.subplots(2,2,figsize=(11,6),layout='constrained')
    for row,label,color,ls in [(c['n0'],'N0 physical clamp',BLUE,'-'),(c['diagnostic'],'Unclamped (nonphysical)',GRAY,'--')]:
        with np.load(row['path']) as z:
            t=np.arange(300)*DT;requested=z['u_mppi']+z['d_hat_used']
            axes[0,0].plot(t+DT,z['err_mm'],label=label,color=color,ls=ls)
            axes[0,1].plot(t,requested[:,2],label=label,color=color,ls=ls)
            axes[1,0].plot(t,np.linalg.norm(requested-z['u_applied'],axis=1),label=label,color=color,ls=ls)
    axes[0,1].axhline(-150,color=ORANGE,ls=':',label='physical lower limit')
    axes[0,1].set(xlim=(2.2,6),ylim=(-163,-137))
    d=json.loads((OLD/'causal_diagnostic_audit.json').read_text())
    axes[1,1].bar(['Clipping component','DOB residual'],[d['steady_target_clip_rms_nm'],d['steady_target_dob_residual_rms_nm']],color=[BLUE,GRAY])
    axes[1,1].set_ylabel('Joint3 torque RMS [Nm]');axes[1,1].set_title('Plateau, 2.5-6 s')
    for ax,x,y in zip(axes.flat[:3],['Time [s]']*3,['EE error [mm]','Requested torque3 [Nm]','Clipping loss norm [Nm]']):
        style(ax,x,y);ax.legend(fontsize=8)
    save(fig,'fig03_bottleneck')


def tuning():
    rows=[json.loads(f.read_text()) for f in (OLD/'sweep').glob('*.json')]
    b=json.loads((OLD/'condition_selection.json').read_text())['selected']['n0']['full_metrics']
    fig,axes=plt.subplots(1,3,figsize=(12,4),sharex=True,sharey=True,layout='constrained')
    for ax,r,color in zip(axes,[.85,.90,.95],[BLUE,ORANGE,PURPLE]):
        rr=sorted([a for a in rows if a['fraction']==r],key=lambda a:a['weight'])
        for i,row in enumerate(rr):
            m=row['full_metrics'];ax.scatter(m['jclip_nm_s'],m['rmse_mm'],color=color,s=40)
            offset=(4,4+i%2*5)
            if r==.90:offset={.3:(-30,-16),1.:(5,8),3.:(-5,-15),10.:(4,15),30.:(-5,8)}[row['weight']]
            if r==.95 and row['weight']==.3:offset=(4,-16)
            ax.annotate(f"w={row['weight']:g}",(m['jclip_nm_s'],m['rmse_mm']),xytext=offset,textcoords='offset points',fontsize=8)
        ax.scatter(b['jclip_nm_s'],b['rmse_mm'],marker='*',s=120,c='black',label='N0')
        if r==.95:
            row=next(a for a in rr if a['weight']==10.)
            ax.scatter(row['full_metrics']['jclip_nm_s'],row['full_metrics']['rmse_mm'],s=130,facecolor='none',edgecolor='black',label='Selected')
        ax.set_title(f'r = {r:.2f}');style(ax,'Clipping integral [Nm s]','EE RMSE [mm]');ax.legend(fontsize=8)
        ax.set(xlim=(1.7,15.2),ylim=(6.4,11.2))
    save(fig,'fig04_pilot_selection')


def paired_figure(pairs):
    fig,axes=plt.subplots(1,2,figsize=(10,4.2),layout='constrained')
    for ax,key,label in zip(axes,['rmse_mm','jclip_nm_s'],['EE RMSE [mm]','Clipping integral [Nm s]']):
        values=np.array([[p[case]['full_metrics'][key] for case in ['n0','n1']] for p in pairs])
        for v in values:ax.plot([0,1],v,color='gray',alpha=.45,lw=1)
        for x,color in [(0,BLUE),(1,ORANGE)]:
            ax.scatter(np.full(len(values),x),values[:,x],color=color,s=30,zorder=3)
        ax.errorbar([0,1],values.mean(0),yerr=values.std(0,ddof=1),fmt='D',color='black',capsize=5,ms=6,label='mean +/- SD')
        ax.set(xticks=[0,1],xticklabels=['N0','N1'],xlim=(-.3,1.3),ylabel=label)
        ax.grid(axis='y',alpha=.2);ax.legend(fontsize=8)
        change=100*(values[:,1].mean()/values[:,0].mean()-1)
        ax.set_title(f'n = {len(pairs)} paired seeds; mean change {change:+.1f}%')
    save(fig,'fig05_primary_paired')


def time_figure(pairs):
    fig,axes=plt.subplots(2,2,figsize=(11,6),layout='constrained');range_req=[]
    for case,color in [('n0',BLUE),('n1',ORANGE)]:
        series=[[],[],[],[]]
        for p in pairs:
            with np.load(p[case]['path']) as z:
                request=z['u_mppi']+z['d_hat_used']
                series[0].append(z['err_mm']);series[1].append(np.cumsum(np.linalg.norm(request-z['u_applied'],axis=1))*DT)
                series[2].append(request[:,2]);series[3].append(np.sqrt(np.mean(z['state_prediction_error'][:,6:]**2,axis=1)))
        t=np.arange(300)*DT
        range_req.extend(np.array(series[2])[:,t>=2.3].ravel())
        for ax,values,tt in zip(axes.flat,series,[t+DT,t+DT,t,t+DT]):
            a=np.asarray(values);ax.plot(tt,a.mean(0),color=color,label=case.upper())
            ax.fill_between(tt,a.min(0),a.max(0),alpha=.13,color=color)
    axes[1,0].axhline(-150,color='black',ls='--');axes[1,0].set(xlim=(2.3,6),ylim=(min(range_req)-1,max(range_req)+1),title='Near-limit interval')
    for ax,y in zip(axes.flat,['EE error [mm]','Cumulative clipping [Nm s]','Requested torque3 [Nm]','1-step dq error RMS [rad/s]']):
        style(ax,'Time [s]',y);ax.legend(fontsize=8)
    save(fig,'fig06_primary_time')


def robustness(new):
    names=['adjacent_131p5','adjacent_132','primary_132p5','adjacent_133'];x=[131.5,132,132.5,133]
    fig,axes=plt.subplots(1,2,figsize=(11,4.3),layout='constrained')
    for ax,key,label in zip(axes,['rmse_mm','jclip_nm_s'],['EE RMSE [mm]','Clipping integral [Nm s]']):
        for case,color in [('n0',BLUE),('n1',ORANGE)]:
            means=[];sd=[]
            for name in names:
                pairs=[p for p in new['pairs'] if p['scenario']==name]
                if not all(p['safe'] for p in pairs):means.append(np.nan);sd.append(0.);continue
                values=[p[case]['full_metrics'][key] for p in pairs]
                means.append(np.mean(values));sd.append(np.std(values,ddof=1))
            ax.errorbar(x,means,yerr=sd,fmt='-o',color=color,capsize=4,label=case.upper())
        style(ax,'Opposing load magnitude [Nm]',label);ax.legend();ax.set_xticks(x)
    save(fig,'fig07_adjacent_loads')


def recovery(new):
    pairs=[p for p in new['pairs'] if p['scenario']=='release_132p5']
    fig,axes=plt.subplots(2,2,figsize=(11,6),layout='constrained')
    for case,color in [('n0',BLUE),('n1',ORANGE)]:
        errors=[];cumulative=[];estimates=[]
        for p in pairs:
            with np.load(p[case]['path']) as z:
                t=np.arange(300)*DT;true=z['d_true'][1:,2]
                errors.append(z['err_mm']);estimates.append(z['d_hat_used'][:,2])
                cumulative.append(np.cumsum(np.linalg.norm(z['u_mppi']+z['d_hat_used']-z['u_applied'],axis=1))*DT)
        for ax,a,tt in [(axes[0,0],estimates,t),(axes[0,1],errors,t+DT),(axes[1,0],cumulative,t+DT)]:
            a=np.array(a);ax.plot(tt,a.mean(0),color=color,label=case.upper())
            ax.fill_between(tt,a.min(0),a.max(0),color=color,alpha=.13)
        windows=['plateau','release','recovery'];vals=np.array([[p[case]['windows'][w]['rmse_mm'] for w in windows] for p in pairs])
        offset=-.17 if case=='n0' else .17
        axes[1,1].bar(np.arange(3)+offset,vals.mean(0),width=.32,yerr=vals.std(0,ddof=1),color=color,capsize=3,label=case.upper())
    axes[0,0].plot(t,true,color='black',ls='--',label='true d3')
    for ax,y in zip([axes[0,0],axes[0,1],axes[1,0]],['Disturbance / estimate3 [Nm]','EE error [mm]','Cumulative clipping [Nm s]']):
        ax.axvspan(3.5,5,color=PURPLE,alpha=.06);ax.axvspan(5,6,color=GRAY,alpha=.06)
        style(ax,'Time [s]',y);ax.legend(fontsize=8)
    axes[1,1].set(xticks=np.arange(3),xticklabels=['Plateau','Removal','Recovery'],ylabel='Window EE RMSE [mm]')
    axes[1,1].grid(axis='y',alpha=.2);axes[1,1].legend(fontsize=8)
    save(fig,'fig08_removal')


def joint_configuration(pairs):
    fig,ax=plt.subplots(figsize=(10,3.7),layout='constrained')
    for case,color,offset in [('n0',BLUE,-.17),('n1',ORANGE,.17)]:
        a=np.array([p[case]['full_metrics']['joint_configuration_rmse_rad'] for p in pairs])
        ax.bar(np.arange(1,7)+offset,a.mean(0),width=.32,yerr=a.std(0,ddof=1),color=color,capsize=3,label=case.upper())
    style(ax,'Joint index','IK configuration deviation RMS [rad]');ax.set_xticks(range(1,7));ax.legend()
    ax.set_title('Supplement: IK configuration is not the controlled joint reference')
    save(fig,'figS1_joint_configuration')


def main():
    OUT.mkdir(parents=True,exist_ok=True);new,primary=load()
    architecture();q0=scenario();diagnostic();tuning();paired_figure(primary);time_figure(primary)
    robustness(new);recovery(new);joint_configuration(primary)
    grouped={name:stats([p for p in new['pairs'] if p['scenario']==name]) for name in [g['scenario'] for g in new['groups']]}
    combined=stats(primary)
    first=stats([p for p in primary if p.get('cohort')=='first5']);additional=stats([p for p in primary if p.get('cohort')=='new5'])
    metadata=dict(primary=combined,first5=first,new5=additional,groups=grouped,initial_q=q0,
        primary_pairs=primary,new_pairs=new['pairs'],new_completed_runs=new['completed_runs'])
    (OUT/'analysis.json').write_text(json.dumps(metadata,indent=2,allow_nan=False))
    with (OUT/'paired_results.csv').open('w',newline='') as f:
        fields=['scenario','seed','cohort','safe','rmse_n0_mm','rmse_n1_mm','jclip_n0_nm_s','jclip_n1_nm_s','maxerr_n0_mm','maxerr_n1_mm']
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
        allpairs=[dict(p,cohort='new5') for p in new['pairs']]+[p for p in primary if p.get('cohort')=='first5']
        for p in allpairs:
            b,n=p['n0']['full_metrics'],p['n1']['full_metrics']
            writer.writerow(dict(scenario=p['scenario'],seed=p['seed'],cohort=p.get('cohort','new5'),safe=p['safe'],
                rmse_n0_mm=b['rmse_mm'],rmse_n1_mm=n['rmse_mm'],jclip_n0_nm_s=b['jclip_nm_s'],jclip_n1_nm_s=n['jclip_nm_s'],
                maxerr_n0_mm=b['max_error_mm'],maxerr_n1_mm=n['max_error_mm']))
    with (OUT/'pilot_runs.csv').open('w',newline='') as f:
        fields=['phase','joint_1based','amplitude_nm','case','seed','fraction','weight','nonphysical_diagnostic','rmse_mm','jclip_nm_s','first_contact_5ms_index','q_violation_steps','dq_violation_steps','raw_path']
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
        for phase in ['screen','refinement','diagnostic','sweep']:
            for path in sorted((OLD/phase).glob('*.json')):
                q=json.loads(path.read_text());m=q['full_metrics']
                writer.writerow(dict(phase=phase,joint_1based=q['joint']+1,amplitude_nm=q['amplitude_nm'],case=q['case'],seed=q['seed'],fraction=q['fraction'],weight=q['weight'],
                    nonphysical_diagnostic=q['nonphysical_diagnostic'],rmse_mm=m['rmse_mm'],jclip_nm_s=m['jclip_nm_s'],first_contact_5ms_index=q['mesh_5ms']['first_collision_index'],
                    q_violation_steps=m['position_violation_steps'],dq_violation_steps=m['velocity_violation_steps'],raw_path=q['path']))
    print('Figures and audited analysis:',OUT)


if __name__=='__main__':main()
