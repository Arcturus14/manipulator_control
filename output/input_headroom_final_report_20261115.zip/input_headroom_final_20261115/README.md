# 최종 보고서 패키지

2026-11-15 / 확정 Base와 r=0.95, w=10 고정.

## 읽는 순서

1. PDF 또는 report.md: 최종 실험 결과와 논문 주장 범위.
2. figure_captions.md: 그림별 논문 캡션, 해석 범위, 발표 설명.
3. figures/: 본문 Figure 1-8, 보조 Figure S1. PNG 300dpi와 SVG 제공.
4. paired_results.csv: 40개 조건-seed 쌍. 같은 5개 새 seed를 여러 부하에서 재사용하므로 40개의 독립 seed를 뜻하지 않는다. Primary에만 서로 다른 10개 seed가 있다.
5. pilot_runs.csv: 예비 탐색, 비물리 unclamped 진단, 가중치 sweep 39회. 실패를 포함하며 진단을 실제 제어 성능으로 해석하지 않는다.
6. analysis.json / report_data.json: 상세 집계 / 구조화 본문.
7. reproducibility/: Base, 동결 manifest, 원자료·소스 SHA256 및 재계산 감사.
8. references.bib: 확인한 관련 문헌. 체계적 신규성 검토는 별도 필요.

## 핵심 결과와 제한

대표 관절3 -132.5 Nm 지속 부하의 10개 seed 모두 RMSE와 clipping 적분을 동시에 줄였다. 평균 변화는 각각 -23.4%, -66.7%다. 인접 부하에서는 개별 악화가 있으며, 제거 중 및 제거 후 회복 RMSE는 소폭 악화했다. 포화 방지나 일반적인 성능 우월성을 보장하지 않는다.

## 원자료와 재현

원시 NPZ는 저장소의 다음 경로에 보존되어 있으며 패키지에 중복 포함하지 않았다.

- kroc/results/position_input_headroom_20261115 (기존49회)
- kroc/results/input_headroom_final_checks_20261115 (추가70회)

실행: CUDA 환경에서 `python -m kroc.final_input_headroom_checks --priority all`.
집계: `python -m kroc.figures_input_headroom_final` 후 `python -m kroc.build_input_headroom_final_report`.
감사: `python -m kroc.audit_final_input_headroom_report`.
PDF: ReportLab/Nanum 폰트가 있는 system Python으로 `/usr/bin/python3 -m kroc.render_input_headroom_final_pdf`.
기준 저장소의 상대 경로를 유지해야 한다. 성능 실험은 CUDA에서만 실행했다. 단위 검증26개는 통과했다.
